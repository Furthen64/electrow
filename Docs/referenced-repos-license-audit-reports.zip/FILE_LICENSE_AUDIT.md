# Phase 1B: First-party source file license audit

Scope: tracked files at the commits below, read from the working tree. Inventory uses Git ls-files, then file extensions and path review; counts are per repository, not unique files across forks. The scan reads complete files and searches for licensing, copyright, origin and restriction terms. A license header means an explicit license or SPDX reference in the first 80 lines; copyright alone is not a license. Generated or third-party candidates are excluded from first-party counts and listed for later review. Ambiguous origin is not resolved by a path heuristic. Files without headers remain unverified where repository scope or provenance is uncertain. CLEAR is provisional, subject to later provenance review.

## circuitjs1-seva77

Commit `6edf7f8a405cb2c52d237182338cbb7a6e52c763`. Tracked files: **682**; source candidates by extension/name: **240**; excluded candidate files: **2**; identified first-party candidates: **238**; read successfully: **238**; unreadable: **0**. Other tracked files excluded: **442**. Working tree status: clean.

### Inventory by top directory and language

| Directory | Extension | Count |
|---|---|---:|
| `.` | `.xml` | 1 |
| `scripts` | `.html` | 1 |
| `scripts` | `.js` | 1 |
| `src` | `.css` | 1 |
| `src` | `.java` | 202 |
| `src` | `.xml` | 1 |
| `templates` | `.sh` | 1 |
| `war` | `.css` | 4 |
| `war` | `.html` | 23 |
| `war` | `.js` | 2 |
| `war` | `.xml` | 1 |

### Header groups

| Group | Files | Eligibility |
|---|---:|---|
| No explicit license header | 67 | UNVERIFIED: assess individual notice and origin |
| GPL 2 or later notice | 169 | CONDITIONAL: preserve notices; GPLv3 option subject to provenance |
| Other / ambiguous license notice | 2 | UNVERIFIED: assess individual notice and origin |

Explicit license header: **171**; without explicit license header: **67**. No blanket incompatibility is inferred from absence: the project-level notice (see Phase 1A) is evidence of intended scope, but origin and authority require later verification. The automated flag list below is a review queue, not a count of proven conflicts.

### Copyright declarations

- * Copyright (C) 2019, 2020 Uri Shaked — 1 occurrence(s), e.g. `war/avr8js/src.avr8js.js:8180`
- * Copyright (C) 2019, 2020, Uri Shaked — 2 occurrence(s), e.g. `war/avr8js/src.avr8js.js:9210`
- * Copyright (C) 2019, Uri Shaked — 3 occurrence(s), e.g. `war/avr8js/src.avr8js.js:7882`
- * Copyright (C) 2020, Uri Shaked — 1 occurrence(s), e.g. `war/avr8js/src.avr8js.js:10648`
- * Copyright (c) 2017 The Polymer Project Authors. All rights reserved. — 15 occurrence(s), e.g. `war/avr8js/src.avr8js.js:130`
- * Copyright (c) 2018 The Polymer Project Authors. All rights reserved. — 3 occurrence(s), e.g. `war/avr8js/src.avr8js.js:718`
- //    Copyright 1995-2006 Sun Microsystems, Inc.  All Rights Reserved — 2 occurrence(s), e.g. `src/main/java/com/lushprojects/circuitjs1/client/Polygon.java:2`
- <p>Copyright (C) 2012 by Daniel Bruce</p> — 1 occurrence(s), e.g. `war/font/webfontlicense.html:29`
- <p>Copyright (C) 2012 by P.J. Onori</p> — 1 occurrence(s), e.g. `war/font/webfontlicense.html:44`
- <p>Copyright (C) 2013 by Aristeides Stathopoulos</p> — 1 occurrence(s), e.g. `war/font/webfontlicense.html:39`
- <p>Copyright (C) 2016 by Dave Gandy</p> — 1 occurrence(s), e.g. `war/font/webfontlicense.html:24`
- <p>Copyright (c) 2012 by John Caserta. All rights reserved.</p> — 1 occurrence(s), e.g. `war/font/webfontlicense.html:34`
- <p>canvas2svg: Copyright (c) 2014 Gliffy Inc.</p> — 1 occurrence(s), e.g. `war/about.html:71`
- As a special exception, the copyright holders of this library give you — 1 occurrence(s), e.g. `src/main/java/com/lushprojects/circuitjs1/client/StringTokenizer.java:33`
- COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER — 1 occurrence(s), e.g. `war/about.html:77`
- Copyright (C) 1989, 1991 Free Software Foundation, Inc. — 1 occurrence(s), e.g. `war/help/license.html:17`
- Copyright (C) 1998, 1999, 2001, 2002, 2005  Free Software Foundation, Inc. — 1 occurrence(s), e.g. `src/main/java/com/lushprojects/circuitjs1/client/StringTokenizer.java:9`
- Copyright (C) <var>yyyy</var>  <var>name of author</var> — 1 occurrence(s), e.g. `war/help/license.html:419`
- Copyright (C) Paul Falstad — 4 occurrence(s), e.g. `src/main/java/com/lushprojects/circuitjs1/client/CCCSElm.java:2`
- Copyright (C) Paul Falstad and Iain Sharp — 158 occurrence(s), e.g. `src/main/java/com/lushprojects/circuitjs1/client/ACRailElm.java:2`
- Copyright (C) Paul Falstad and Usevalad Khatkevich — 2 occurrence(s), e.g. `src/main/java/com/lushprojects/circuitjs1/client/LicenseDialog.java:2`
- Copyright (C) Paul Falstad, Iain Sharp and Usevalad Khatkevich — 1 occurrence(s), e.g. `src/main/java/com/lushprojects/circuitjs1/client/HelpDialog.java:2`
- Copyright (c) 1985-1991 The Regents of the University of California. — 1 occurrence(s), e.g. `war/about.html:60`
- Copyright (c) 2019 The Polymer Project Authors. All rights reserved. — 1 occurrence(s), e.g. `war/avr8js/src.avr8js.js:3580`
- Gnomovision version 69, Copyright (C) <var>year</var> <var>name of author</var> — 1 occurrence(s), e.g. `war/help/license.html:446`
- OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES — 1 occurrence(s), e.g. `war/help/license.html:378`
- WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR — 1 occurrence(s), e.g. `war/help/license.html:390`
- We protect your rights with two steps: (1) copyright the software, and — 1 occurrence(s), e.g. `war/help/license.html:63`
- Yoyodyne, Inc., hereby disclaims all copyright — 1 occurrence(s), e.g. `war/help/license.html:469`
- a notice placed by the copyright holder saying it may be distributed — 1 occurrence(s), e.g. `war/help/license.html:97`
- announcement including an appropriate copyright notice and a — 1 occurrence(s), e.g. `war/help/license.html:161`
- certain countries either by patents or by copyrighted interfaces, the — 1 occurrence(s), e.g. `war/help/license.html:335`
- copyright notice and disclaimer of warranty; keep intact all the — 1 occurrence(s), e.g. `war/help/license.html:121`
- means either the Program or any derivative work under copyright law: — 1 occurrence(s), e.g. `war/help/license.html:100`
- original copyright holder who places the Program under this License — 1 occurrence(s), e.g. `war/help/license.html:336`
- school, if any, to sign a "copyright disclaimer" for the program, if — 1 occurrence(s), e.g. `war/help/license.html:463`
- the "copyright" line and a pointer to where the full notice is found. — 1 occurrence(s), e.g. `war/help/license.html:414`
- to ask for permission.  For software which is copyrighted by the Free — 1 occurrence(s), e.g. `war/help/license.html:365`

### Files without an explicit license header

- `pom.xml`
- `scripts/dev_n_build.js`
- `scripts/devmode/index.html`
- `src/main/java/com/lushprojects/circuitjs1/circuitjs1.gwt.xml`
- `src/main/java/com/lushprojects/circuitjs1/client/Adjustable.java`
- `src/main/java/com/lushprojects/circuitjs1/client/AudioOutputElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/ComparatorElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/CompositeElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/CustomCompositeElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/CustomCompositeModel.java`
- `src/main/java/com/lushprojects/circuitjs1/client/CustomLogicElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/CustomLogicModel.java`
- `src/main/java/com/lushprojects/circuitjs1/client/DCMotorElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/DarlingtonElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/DataRecorderElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/DiodeModel.java`
- `src/main/java/com/lushprojects/circuitjs1/client/EditDiodeModelDialog.java`
- `src/main/java/com/lushprojects/circuitjs1/client/EditTransistorModelDialog.java`
- `src/main/java/com/lushprojects/circuitjs1/client/Expr.java`
- `src/main/java/com/lushprojects/circuitjs1/client/ImportFromDropbox.java`
- `src/main/java/com/lushprojects/circuitjs1/client/ImportFromDropboxDialog.java`
- `src/main/java/com/lushprojects/circuitjs1/client/IntPair.java`
- `src/main/java/com/lushprojects/circuitjs1/client/LDRElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/NDarlingtonElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/OTAElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/OhmMeterElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/OpAmpRealElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/OptocouplerElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/PDarlingtonElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/PolarCapacitorElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/ScopePropertiesDialog.java`
- `src/main/java/com/lushprojects/circuitjs1/client/SubcircuitDialog.java`
- `src/main/java/com/lushprojects/circuitjs1/client/ThermistorNTCElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/ThreePhaseMotorElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/Toolbar.java`
- `src/main/java/com/lushprojects/circuitjs1/client/TransistorModel.java`
- `src/main/java/com/lushprojects/circuitjs1/client/VaractorElm.java`
- `src/main/java/com/lushprojects/circuitjs1/client/util/PerfMonitor.java`
- `src/main/java/com/lushprojects/circuitjs1/public/style.css`
- `templates/update_languages.sh`
- `war/WEB-INF/web.xml`
- `war/avr8js/analog.html`
- `war/avr8js/index.html`
- `war/avr8js/logic.html`
- `war/avr8js/src.avr8js.css`
- `war/avr8js/src.avr8js.js`
- `war/blink-test.html`
- `war/circuitjs.html`
- `war/crystal.html`
- `war/customfunction.html`
- `war/customlogic.html`
- `war/customtransformer.html`
- `war/diodecalc.html`
- `war/font/fontello.css`
- `war/font/runstopbtn.css`
- `war/help/DA.html`
- `war/help/DE.html`
- `war/help/EN.html`
- `war/help/PL.html`
- `war/help/RU.html`
- `war/help/helpstyle.css`
- `war/index.html`
- `war/js/sys.js`
- `war/jsinterface.html`
- `war/mosfet-beta.html`
- `war/opampreal.html`
- `war/subcircuits.html`

### Other explicit or ambiguous headers

- `war/font/webfontlicense.html`: 22: <h3>Font license info</h3>; 24: <p>Copyright (C) 2016 by Dave Gandy</p>; 26: License: SIL (<a href="javascript:nw.Shell.openExternal('http://scripts.sil.org/OFL');">http://scripts.sil.org/OFL</a>)<br>; 29: <p>Copyright (C) 2012 by Daniel Bruce</p>; 31: License: SIL (<a href="javascript:nw.Shell.openExternal('http://scripts.sil.org/OFL');">http://scripts.sil.org/OFL</a>)<br>
- `war/help/license.html`: 7: <title>GNU GENERAL PUBLIC LICENSE Version 2</title>; 11: <h3><a id="SEC1">GNU GENERAL PUBLIC LICENSE</a></h3>; 17: Copyright (C) 1989, 1991 Free Software Foundation, Inc.; 21: of this license document, but changing it is not allowed.; 27: The licenses for most software are designed to take away your

### Potential exceptions and external-origin references (automated review queue)

- `src/main/java/com/lushprojects/circuitjs1/client/ACRailElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ACVoltageElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ADCElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/AMElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/AboutBox.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/AmmeterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/AnalogSwitch2Elm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/AnalogSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/AndGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/AntennaElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/AudioInputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/BoxElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/CC2Elm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/CCCSElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/CCVSElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/CapacitorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/Checkbox.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/CheckboxAlignedMenuItem.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/CheckboxMenuItem.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ChipElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/Choice.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/CirSim.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/CirSim.java:120` — MenuItem licenseItem;
- `src/main/java/com/lushprojects/circuitjs1/client/CirSim.java:270` — static LicenseDialog licenseDialog;
- `src/main/java/com/lushprojects/circuitjs1/client/CirSim.java:412` — // this code is taken from original ExportAsLocalFileDialog.java:
- `src/main/java/com/lushprojects/circuitjs1/client/CirSim.java:3612` — if (item=="license")
- `src/main/java/com/lushprojects/circuitjs1/client/CirSim.java:3613` — licenseDialog = new LicenseDialog();
- `src/main/java/com/lushprojects/circuitjs1/client/CirSim.java:4233` — licenseItem=iconMenuItem("license", "License",(Command)null);
- `src/main/java/com/lushprojects/circuitjs1/client/CirSim.java:4234` — h.addItem(licenseItem);
- `src/main/java/com/lushprojects/circuitjs1/client/CirSim.java:4235` — licenseItem.setScheduledCommand(new MyCommand("file","license"));
- `src/main/java/com/lushprojects/circuitjs1/client/CirSim.java:5913` — if (licenseDialog !=null && licenseDialog.isShowing())
- `src/main/java/com/lushprojects/circuitjs1/client/CircuitElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/CircuitNode.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/CircuitNodeLink.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ClockElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/Color.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/Counter2Elm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/CounterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/CrossSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/CrystalElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/CurrentElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/CustomCompositeChipElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/CustomTransformerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/DACElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/DCMotorElm.java:5` — // based on https://ctms.engin.umich.edu/CTMS/index.php?example=MotorPosition&section=SystemModeling
- `src/main/java/com/lushprojects/circuitjs1/client/DCVoltageElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/DFlipFlopElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/DPDTSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/DataInputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/DeMultiplexerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/DecimalDisplayElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/DelayBufferElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/DiacElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/Dialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/Diode.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/DiodeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/EditCompositeModelDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/EditDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/EditDialogLoadFile.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/EditInfo.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/EditOptions.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ExportAsImageDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ExportAsLocalFileDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ExportAsTextDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ExportAsUrlDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ExtVoltageElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/FFT.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/FFT.java:52` — * Based on
- `src/main/java/com/lushprojects/circuitjs1/client/FMElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/Font.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/FullAdderElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/FuseElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/GateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/GraphicElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/Graphics.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/GroundElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/HalfAdderElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/HelpDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ImportFromTextDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/Inductor.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/InductorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/InverterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/InvertingSchmittElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/JKFlipFlopElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/JfetElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/JfetElm.java:131` — // these values are taken from Hayes+Horowitz p155
- `src/main/java/com/lushprojects/circuitjs1/client/LEDArrayElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/LEDElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/LabeledNodeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/LampElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/LampElm.java:148` — // based on http://www.intusoft.com/nlpdf/nl11.pdf
- `src/main/java/com/lushprojects/circuitjs1/client/LatchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/LicenseDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/LicenseDialog.java:30` — public class LicenseDialog extends DialogBox {
- `src/main/java/com/lushprojects/circuitjs1/client/LicenseDialog.java:35` — LicenseDialog() {
- `src/main/java/com/lushprojects/circuitjs1/client/LicenseDialog.java:39` — setText(Locale.LS("License"));
- `src/main/java/com/lushprojects/circuitjs1/client/LicenseDialog.java:41` — vp.add(new HTML("<iframe style=\"border:0;\" src=\"help/license.html\" width=\"500\" height=\"400\" scrolling=\"auto\" frameborder=\"1\"></iframe>"));
- `src/main/java/com/lushprojects/circuitjs1/client/LineElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/LoadFile.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/LogicInputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/LogicOutputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/MBBSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/MemristorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ModDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/MonostableElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/MosfetElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/MotorProtectionSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/MultiplexerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/MyCommand.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/NJfetElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/NMosfetElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/NTransistorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/NandGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/NoiseElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/NorGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/OpAmpElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/OpAmpSwapElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/OptocouplerElm.java:95` — // adapted from ChipElm
- `src/main/java/com/lushprojects/circuitjs1/client/OrGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/OutputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/PMosfetElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/PTransistorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/PhaseCompElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/PisoShiftElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/Point.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/Polygon.java:2` — //    Copyright 1995-2006 Sun Microsystems, Inc.  All Rights Reserved
- `src/main/java/com/lushprojects/circuitjs1/client/Polygon.java:15` — //    along with this program.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/PotElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ProbeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ProbeElm.java:24` — // much of this was adapted from Bill Collis's code in TestPointElm.java
- `src/main/java/com/lushprojects/circuitjs1/client/PushSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/QueryParameters.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/RailElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/Rectangle.java:2` — //    Copyright 1995-2006 Sun Microsystems, Inc.  All Rights Reserved
- `src/main/java/com/lushprojects/circuitjs1/client/Rectangle.java:15` — //    along with this program.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/RelayCoilElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/RelayContactElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/RelayElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ResistorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/RingCounterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/RowInfo.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/SCRElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/SRAMElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/SRAMLoadFile.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/SchmittElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/Scope.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ScopeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ScopePopupMenu.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ScrollValuePopup.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/Scrollbar.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/SearchDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/SeqGenElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/SevenSegDecoderElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/SevenSegElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ShortcutsDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/SipoShiftElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/SliderDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/SparkGapElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/SquareRailElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/StopTriggerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/StringTokenizer.java:21` — General Public License for more details.
- `src/main/java/com/lushprojects/circuitjs1/client/StringTokenizer.java:29` — making a combined work based on this library.  Thus, the terms and
- `src/main/java/com/lushprojects/circuitjs1/client/StringTokenizer.java:35` — executable, regardless of the license terms of these independent
- `src/main/java/com/lushprojects/circuitjs1/client/StringTokenizer.java:38` — independent module, the terms and conditions of the license of that
- `src/main/java/com/lushprojects/circuitjs1/client/StringTokenizer.java:39` — module.  An independent module is a module which is not derived from
- `src/main/java/com/lushprojects/circuitjs1/client/StringTokenizer.java:40` — or based on this library.  If you modify this library, you may extend
- `src/main/java/com/lushprojects/circuitjs1/client/SweepElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/Switch2Elm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/SwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/TFlipFlopElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/TappedTransformerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/TestPointElm.java:19` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/TextElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ThreePhaseMotorElm.java:7` — // based on https://ctms.engin.umich.edu/CTMS/index.php?example=MotorPosition&section=SystemModeling
- `src/main/java/com/lushprojects/circuitjs1/client/ThreePhaseMotorElm.java:101` — // based on https://forum.kicad.info/t/ac-motors-simulation-1-phase-3-phase/14188/3
- `src/main/java/com/lushprojects/circuitjs1/client/TimeDelayRelayElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/TimerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/TransLineElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/TransformerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/TransistorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/TriStateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/TriacElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/TriodeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/TunnelDiodeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/UnijunctionElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/VCCSElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/VCOElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/VCVSElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/VarRailElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/VoltageElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/WattmeterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/WireElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/XorGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/ZenerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/circuitjs1.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/main/java/com/lushprojects/circuitjs1/client/util/Locale.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `war/about.html:53` — <p style="font-size:9px">This program uses free icons. For more information, please read the <a href="font/webfontlicense.html" target="_self">list of authors and licenses of these icons and webfonts</a>.</p>
- `war/about.html:61` — All rights reserved.</p>
- `war/avr8js/src.avr8js.js:92` — // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
- `war/avr8js/src.avr8js.js:129` — * @license
- `war/avr8js/src.avr8js.js:130` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:131` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:132` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:187` — * @license
- `war/avr8js/src.avr8js.js:188` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:189` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:190` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:472` — * @license
- `war/avr8js/src.avr8js.js:473` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:474` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:475` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:641` — * @license
- `war/avr8js/src.avr8js.js:642` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:643` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:644` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:717` — * @license
- `war/avr8js/src.avr8js.js:718` — * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:719` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:720` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:755` — * @license
- `war/avr8js/src.avr8js.js:756` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:757` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:758` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:920` — * @license
- `war/avr8js/src.avr8js.js:921` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:922` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:923` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:962` — // parser. The marker type is based on whether the expression is in an
- `war/avr8js/src.avr8js.js:1063` — * @license
- `war/avr8js/src.avr8js.js:1064` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:1065` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:1066` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:1615` — * @license
- `war/avr8js/src.avr8js.js:1616` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:1617` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:1618` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:1684` — * @license
- `war/avr8js/src.avr8js.js:1685` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:1686` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:1687` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:1746` — * @license
- `war/avr8js/src.avr8js.js:1747` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:1748` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:1749` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:1997` — * @license
- `war/avr8js/src.avr8js.js:1998` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:1999` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:2000` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:2094` — * @license
- `war/avr8js/src.avr8js.js:2095` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:2096` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:2097` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:2373` — // (which might cause them to render based on a common pattern of
- `war/avr8js/src.avr8js.js:2419` — * @license
- `war/avr8js/src.avr8js.js:2420` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:2421` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:2422` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:2969` — * be called when an element should update based on some state not triggered
- `war/avr8js/src.avr8js.js:3204` — * @license
- `war/avr8js/src.avr8js.js:3205` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:3206` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:3207` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:3579` — @license
- `war/avr8js/src.avr8js.js:3580` — Copyright (c) 2019 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:3581` — This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:3582` — http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
- `war/avr8js/src.avr8js.js:3748` — * @license
- `war/avr8js/src.avr8js.js:3749` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:3750` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:3751` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:3870` — } // There are three separate cases here based on Shadow DOM support.
- `war/avr8js/src.avr8js.js:6435` — * @license
- `war/avr8js/src.avr8js.js:6436` — * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:6437` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:6438` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:6538` — /** The potentiometer SVG is taken from https://freesvg.org/potentiometer and some of the
- `war/avr8js/src.avr8js.js:6539` — functions are taken from https://github.com/vitaliy-bobrov/js-rocks knob component */
- `war/avr8js/src.avr8js.js:7372` — * @license
- `war/avr8js/src.avr8js.js:7373` — * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:7374` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:7375` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:7462` — }); // Add or remove classes based on their classMap value
- `war/avr8js/src.avr8js.js:8177` — * Instruction timing is currently based on ATmega328p (see the Instruction Set Summary at the end of
- `war/font/fontello.css:50` — /* Font smoothing. That was taken from TWBS */
- `war/font/fontello.css:99` — .cirjsicon-license:before { content: '📰'; } /* '\1f4f0' */
- `war/font/runstopbtn.css:49` — /* Font smoothing. That was taken from TWBS */
- `war/font/webfontlicense.html:22` — <h3>Font license info</h3>
- `war/font/webfontlicense.html:26` — License: SIL (<a href="javascript:nw.Shell.openExternal('http://scripts.sil.org/OFL');">http://scripts.sil.org/OFL</a>)<br>
- `war/font/webfontlicense.html:31` — License: SIL (<a href="javascript:nw.Shell.openExternal('http://scripts.sil.org/OFL');">http://scripts.sil.org/OFL</a>)<br>
- `war/font/webfontlicense.html:34` — <p>Copyright (c) 2012 by John Caserta. All rights reserved.</p>
- `war/font/webfontlicense.html:36` — License: SIL (<a href="javascript:nw.Shell.openExternal('http://scripts.sil.org/OFL');">http://scripts.sil.org/OFL</a>)<br>
- `war/font/webfontlicense.html:41` — License: SIL (<a href="javascript:nw.Shell.openExternal('http://scripts.sil.org/OFL');">http://scripts.sil.org/OFL</a>)<br>
- `war/font/webfontlicense.html:46` — License: SIL (<a href="javascript:nw.Shell.openExternal('http://scripts.sil.org/OFL');">http://scripts.sil.org/OFL</a>)<br>
- `war/font/webfontlicense.html:49` — <h3>Icon license info</h3>
- `war/help/EN.html:29` — <a href="#p6">&nbsp;<span>&#8594;</span>&nbsp;<b>License</b></a>
- `war/help/EN.html:31` — <font size="-1"><b><i>The main part of the information is taken from the <a href="javascript:nw.Shell.openExternal('http://lushprojects.com/circuitjs/');">http://lushprojects.com/circuitjs/</a></i></b>
- `war/help/EN.html:100` — voltages and currents in the circuit are calculated based on the component models and the current circuit
- `war/help/EN.html:181` — <h3 id="p6">License</h3>
- `war/help/EN.html:191` — Public License for more details.</font><br><br>
- `war/help/EN.html:192` — <font>For details of licensing see <a href="javascript:nw.Shell.openExternal('http://www.gnu.org/licenses/');">http://www.gnu.org/licenses/</a>.</font><br><br>
- `war/help/RU.html:121` — <font>Вы должны были получить копию Стандартной общественной лицензии GNU вместе с этой программой. Если это не так, см. <a href="javascript:nw.Shell.openExternal('http://www.gnu.org/licenses/');">http://www.gnu.org/licenses/</a>.</font><br><br>
- `war/help/license.html:21` — of this license document, but changing it is not allowed.
- `war/help/license.html:27` — The licenses for most software are designed to take away your
- `war/help/license.html:29` — License is intended to guarantee your freedom to share and change free
- `war/help/license.html:31` — General Public License applies to most of the Free Software
- `war/help/license.html:34` — the GNU Lesser General Public License instead.)  You can apply it to
- `war/help/license.html:40` — price.  Our General Public Licenses are designed to make sure that you
- `war/help/license.html:64` — (2) offer you this license which gives you legal permission to copy,
- `war/help/license.html:80` — program will individually obtain patent licenses, in effect making the
- `war/help/license.html:82` — patent must be licensed for everyone's free use or not licensed at all.
- `war/help/license.html:96` — This License applies to any program or other work which contains
- `war/help/license.html:98` — under the terms of this General Public License.  The "Program", below,
- `war/help/license.html:99` — refers to any such program or work, and a "work based on the Program"
- `war/help/license.html:104` — the term "modification".)  Each licensee is addressed as "you".
- `war/help/license.html:109` — covered by this License; they are outside its scope.  The act of
- `war/help/license.html:111` — is covered only if its contents constitute a work based on the
- `war/help/license.html:122` — notices that refer to this License and to the absence of any warranty;
- `war/help/license.html:123` — and give any other recipients of the Program a copy of this License
- `war/help/license.html:135` — of it, thus forming a work based on the Program, and copy and
- `war/help/license.html:151` — whole or in part contains or is derived from the Program or any
- `war/help/license.html:152` — part thereof, to be licensed as a whole at no charge to all third
- `war/help/license.html:153` — parties under the terms of this License.
- `war/help/license.html:165` — License.  (Exception: if the Program itself is interactive but
- `war/help/license.html:166` — does not normally print such an announcement, your work based on
- `war/help/license.html:173` — identifiable sections of that work are not derived from the Program,
- `war/help/license.html:175` — themselves, then this License, and its terms, do not apply to those
- `war/help/license.html:179` — this License, whose permissions for other licensees extend to the
- `war/help/license.html:187` — collective works based on the Program.
- `war/help/license.html:191` — In addition, mere aggregation of another work not based on the Program
- `war/help/license.html:192` — with the Program (or with a work based on the Program) on a volume of
- `war/help/license.html:194` — the scope of this License.
- `war/help/license.html:199` — You may copy and distribute the Program (or a work based on it,
- `war/help/license.html:230` — allowed only for noncommercial distribution and only if you
- `war/help/license.html:259` — You may not copy, modify, sublicense, or distribute the Program
- `war/help/license.html:260` — except as expressly provided under this License.  Any attempt
- `war/help/license.html:261` — otherwise to copy, modify, sublicense or distribute the Program is
- `war/help/license.html:262` — void, and will automatically terminate your rights under this License.
- `war/help/license.html:264` — this License will not have their licenses terminated so long as such
- `war/help/license.html:270` — You are not required to accept this License, since you have not
- `war/help/license.html:273` — prohibited by law if you do not accept this License.  Therefore, by
- `war/help/license.html:274` — modifying or distributing the Program (or any work based on the
- `war/help/license.html:275` — Program), you indicate your acceptance of this License to do so, and
- `war/help/license.html:277` — the Program or works based on it.
- `war/help/license.html:282` — Each time you redistribute the Program (or any work based on the
- `war/help/license.html:283` — Program), the recipient automatically receives a license from the
- `war/help/license.html:288` — this License.
- `war/help/license.html:296` — otherwise) that contradict the conditions of this License, they do not
- `war/help/license.html:297` — excuse you from the conditions of this License.  If you cannot
- `war/help/license.html:299` — License and any other pertinent obligations, then as a consequence you
- `war/help/license.html:301` — license would not permit royalty-free redistribution of the Program by
- `war/help/license.html:303` — the only way you could satisfy both it and this License would be to
- `war/help/license.html:319` — implemented by public license practices.  Many people have made
- `war/help/license.html:323` — to distribute software through any other system and a licensee cannot
- `war/help/license.html:329` — be a consequence of the rest of this License.
- `war/help/license.html:336` — original copyright holder who places the Program under this License
- `war/help/license.html:339` — countries not thus excluded.  In such case, this License incorporates
- `war/help/license.html:340` — the limitation as if written in the body of this License.
- `war/help/license.html:346` — of the General Public License from time to time.  Such new versions will
- `war/help/license.html:353` — specifies a version number of this License which applies to it and "any
- `war/help/license.html:357` — this License, you may choose any version ever published by the Free Software
- `war/help/license.html:376` — BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
- `war/help/license.html:455` — the appropriate parts of the General Public License.  Of course, the
- `war/help/license.html:479` — This General Public License does not permit incorporating your program into
- `war/help/license.html:483` — Public License instead of this License.

### Excluded source candidates for separate dependency/generated-code review

- `war/canvas2svg.js`
- `war/lz-string.min.js`

## circuitjs1-vactrol

Commit `9baa268125f70391c5c24b6e1749c308a0e25ca0`. Tracked files: **823**; source candidates by extension/name: **316**; excluded candidate files: **4**; identified first-party candidates: **312**; read successfully: **312**; unreadable: **0**. Other tracked files excluded: **507**. Working tree status: clean.

### Inventory by top directory and language

| Directory | Extension | Count |
|---|---|---:|
| `.` | `.gradle` | 1 |
| `.` | `.sh` | 2 |
| `.settings` | `.xml` | 1 |
| `app` | `.js` | 2 |
| `browser-tests` | `.html` | 4 |
| `lang` | `.py` | 3 |
| `lang` | `.sh` | 1 |
| `model-tests` | `.java` | 2 |
| `scripts` | `.ps1` | 1 |
| `src` | `.css` | 1 |
| `src` | `.java` | 251 |
| `src` | `.xml` | 1 |
| `war` | `.css` | 3 |
| `war` | `.html` | 32 |
| `war` | `.js` | 2 |
| `war` | `.sh` | 1 |
| `war` | `.xml` | 1 |
| `websocket` | `.html` | 1 |
| `websocket` | `.js` | 1 |
| `websocket` | `.py` | 1 |

### Header groups

| Group | Files | Eligibility |
|---|---:|---|
| No explicit license header | 112 | UNVERIFIED: assess individual notice and origin |
| SPDX GPL-3.0-or-later | 7 | CONDITIONAL: preserve notices; GPLv3 option subject to provenance |
| Other / ambiguous license notice | 3 | UNVERIFIED: assess individual notice and origin |
| GPL 2 or later notice | 186 | CONDITIONAL: preserve notices; GPLv3 option subject to provenance |
| Apache notice | 4 | UNVERIFIED: assess individual notice and origin |

Explicit license header: **200**; without explicit license header: **112**. No blanket incompatibility is inferred from absence: the project-level notice (see Phase 1A) is evidence of intended scope, but origin and authority require later verification. The automated flag list below is a review queue, not a count of proven conflicts.

### Copyright declarations

- * Copyright (C) 2019, 2020 Uri Shaked — 1 occurrence(s), e.g. `war/avr8js/src.avr8js.js:8180`
- * Copyright (C) 2019, 2020, Uri Shaked — 2 occurrence(s), e.g. `war/avr8js/src.avr8js.js:9210`
- * Copyright (C) 2019, Uri Shaked — 3 occurrence(s), e.g. `war/avr8js/src.avr8js.js:7882`
- * Copyright (C) 2020, Uri Shaked — 1 occurrence(s), e.g. `war/avr8js/src.avr8js.js:10648`
- * Copyright (C) 2026 Nerding and Hoarding — 3 occurrence(s), e.g. `src/com/lushprojects/circuitjs1/client/BjtAvalancheModel.java:2`
- * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved. — 4 occurrence(s), e.g. `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:3`
- * Copyright (c) 2017 The Polymer Project Authors. All rights reserved. — 15 occurrence(s), e.g. `war/avr8js/src.avr8js.js:130`
- * Copyright (c) 2018 The Polymer Project Authors. All rights reserved. — 3 occurrence(s), e.g. `war/avr8js/src.avr8js.js:718`
- * Desktop wrapper modifications Copyright (C) 2026 Nerding and Hoarding. — 2 occurrence(s), e.g. `app/main.js:2`
- //    Copyright 1995-2006 Sun Microsystems, Inc.  All Rights Reserved — 2 occurrence(s), e.g. `src/com/lushprojects/circuitjs1/client/Polygon.java:2`
- <p>Copyright (C) 2012 by Daniel Bruce</p> — 1 occurrence(s), e.g. `war/font/webfontlicense.html:18`
- <p>Copyright (C) 2013 by Aristeides Stathopoulos</p> — 1 occurrence(s), e.g. `war/font/webfontlicense.html:28`
- <p>Copyright (C) 2016 by Dave Gandy</p> — 1 occurrence(s), e.g. `war/font/webfontlicense.html:13`
- <p>Copyright (c) 2012 by John Caserta. All rights reserved.</p> — 1 occurrence(s), e.g. `war/font/webfontlicense.html:23`
- <p>Modifications Copyright © 2026 Nerding and Hoarding. Distributed under the <a href="LICENSE">GNU General Public License v3 or later</a>.</p> — 1 occurrence(s), e.g. `war/index.html:69`
- <p>canvas2svg: Copyright (c) 2014 Gliffy Inc.</p> — 1 occurrence(s), e.g. `war/about.html:43`
- As a special exception, the copyright holders of this library give you — 1 occurrence(s), e.g. `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:33`
- COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER — 1 occurrence(s), e.g. `war/about.html:49`
- Copyright (C) 1998, 1999, 2001, 2002, 2005  Free Software Foundation, Inc. — 1 occurrence(s), e.g. `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:9`
- Copyright (C) Paul Falstad — 5 occurrence(s), e.g. `src/com/lushprojects/circuitjs1/client/CCCSElm.java:2`
- Copyright (C) Paul Falstad and Iain Sharp — 177 occurrence(s), e.g. `src/com/lushprojects/circuitjs1/client/ACRailElm.java:2`
- Copyright (c) 1985-1991 The Regents of the University of California. — 1 occurrence(s), e.g. `war/about.html:32`
- Copyright (c) 2019 The Polymer Project Authors. All rights reserved. — 1 occurrence(s), e.g. `war/avr8js/src.avr8js.js:3580`

### Files without an explicit license header

- `.settings/org.eclipse.wst.common.project.facet.core.xml`
- `browser-tests/audio-output-browser-test.html`
- `browser-tests/bjt-avalanche-browser-test.html`
- `browser-tests/reverse-avalanche-oscillator-browser-test.html`
- `browser-tests/vactrol-browser-test.html`
- `dev.sh`
- `lang/findmissing.py`
- `lang/getstrings.py`
- `lang/makemissing.sh`
- `lang/maketemplate.py`
- `model-tests/com/lushprojects/circuitjs1/client/BjtAvalancheModelTest.java`
- `model-tests/com/lushprojects/circuitjs1/client/VactrolModelTest.java`
- `scripts/package-windows.ps1`
- `src/com/lushprojects/circuitjs1/circuitjs1.gwt.xml`
- `src/com/lushprojects/circuitjs1/client/Adjustable.java`
- `src/com/lushprojects/circuitjs1/client/CircuitLoader.java`
- `src/com/lushprojects/circuitjs1/client/CircuitMatrix.java`
- `src/com/lushprojects/circuitjs1/client/CommandManager.java`
- `src/com/lushprojects/circuitjs1/client/ComparatorElm.java`
- `src/com/lushprojects/circuitjs1/client/CompositeElm.java`
- `src/com/lushprojects/circuitjs1/client/CustomCompositeElm.java`
- `src/com/lushprojects/circuitjs1/client/CustomCompositeModel.java`
- `src/com/lushprojects/circuitjs1/client/CustomLogicElm.java`
- `src/com/lushprojects/circuitjs1/client/CustomLogicModel.java`
- `src/com/lushprojects/circuitjs1/client/DCMotorElm.java`
- `src/com/lushprojects/circuitjs1/client/DarlingtonElm.java`
- `src/com/lushprojects/circuitjs1/client/DataRecorderElm.java`
- `src/com/lushprojects/circuitjs1/client/DiodeModel.java`
- `src/com/lushprojects/circuitjs1/client/EditDiodeModelDialog.java`
- `src/com/lushprojects/circuitjs1/client/EditMosfetModelDialog.java`
- `src/com/lushprojects/circuitjs1/client/EditRelayModelDialog.java`
- `src/com/lushprojects/circuitjs1/client/EditTransistorModelDialog.java`
- `src/com/lushprojects/circuitjs1/client/ElementFactory.java`
- `src/com/lushprojects/circuitjs1/client/Expr.java`
- `src/com/lushprojects/circuitjs1/client/FindPathInfo.java`
- `src/com/lushprojects/circuitjs1/client/ImageExporter.java`
- `src/com/lushprojects/circuitjs1/client/ImportFromDropbox.java`
- `src/com/lushprojects/circuitjs1/client/ImportFromDropboxDialog.java`
- `src/com/lushprojects/circuitjs1/client/IntPair.java`
- `src/com/lushprojects/circuitjs1/client/JSInterface.java`
- `src/com/lushprojects/circuitjs1/client/LDRElm.java`
- `src/com/lushprojects/circuitjs1/client/MosfetModel.java`
- `src/com/lushprojects/circuitjs1/client/NDarlingtonElm.java`
- `src/com/lushprojects/circuitjs1/client/OTAElm.java`
- `src/com/lushprojects/circuitjs1/client/OhmMeterElm.java`
- `src/com/lushprojects/circuitjs1/client/OpAmpRealElm.java`
- `src/com/lushprojects/circuitjs1/client/OptocouplerElm.java`
- `src/com/lushprojects/circuitjs1/client/PDarlingtonElm.java`
- `src/com/lushprojects/circuitjs1/client/PolarCapacitorElm.java`
- `src/com/lushprojects/circuitjs1/client/RelayModel.java`
- `src/com/lushprojects/circuitjs1/client/ScopeDataIterator.java`
- `src/com/lushprojects/circuitjs1/client/ScopeFFT.java`
- `src/com/lushprojects/circuitjs1/client/ScopeOverlays.java`
- `src/com/lushprojects/circuitjs1/client/ScopePlot2d.java`
- `src/com/lushprojects/circuitjs1/client/ScopePropertiesDialog.java`
- `src/com/lushprojects/circuitjs1/client/ScopeSerializer.java`
- `src/com/lushprojects/circuitjs1/client/SimulationManager.java`
- `src/com/lushprojects/circuitjs1/client/SubcircuitBar.java`
- `src/com/lushprojects/circuitjs1/client/SubcircuitDialog.java`
- `src/com/lushprojects/circuitjs1/client/TestCreator.java`
- `src/com/lushprojects/circuitjs1/client/TestManager.java`
- `src/com/lushprojects/circuitjs1/client/ThermistorNTCElm.java`
- `src/com/lushprojects/circuitjs1/client/ThreePhaseMotorElm.java`
- `src/com/lushprojects/circuitjs1/client/Toolbar.java`
- `src/com/lushprojects/circuitjs1/client/UIManager.java`
- `src/com/lushprojects/circuitjs1/client/VaractorElm.java`
- `src/com/lushprojects/circuitjs1/client/VoltageSource.java`
- `src/com/lushprojects/circuitjs1/client/WireConverter.java`
- `src/com/lushprojects/circuitjs1/client/WireRouter.java`
- `src/com/lushprojects/circuitjs1/client/util/PerfMonitor.java`
- `src/com/lushprojects/circuitjs1/public/style.css`
- `src/com/lushprojects/circuitjs1/rebind/ElementFactoryGenerator.java`
- `test.sh`
- `war/WEB-INF/web.xml`
- `war/avr8js/analog.html`
- `war/avr8js/index.html`
- `war/avr8js/logic.html`
- `war/avr8js/src.avr8js.css`
- `war/avr8js/src.avr8js.js`
- `war/blink-test.html`
- `war/circuitjs.html`
- `war/crystal.html`
- `war/customfunction.html`
- `war/customlogic.html`
- `war/customtransformer.html`
- `war/diodecalc.html`
- `war/doc/AudioInput.html`
- `war/doc/DataInput.html`
- `war/doc/DelayBuffer.html`
- `war/doc/circuits.html`
- `war/doc/customfunction.html`
- `war/doc/customlogic.html`
- `war/doc/customtransformer.html`
- `war/doc/index.html`
- `war/doc/js-interface.html`
- `war/doc/opampreal.html`
- `war/doc/overview.html`
- `war/doc/subcircuits.html`
- `war/doc/toc.html`
- `war/doc/welcome.html`
- `war/font/fontello.css`
- `war/iframe.html`
- `war/jsinterface.html`
- `war/mosfet-beta.html`
- `war/opampreal.html`
- `war/service-worker.js`
- `war/showcase.css`
- `war/subcircuits.html`
- `war/update-service-worker.sh`
- `websocket/circuitws.html`
- `websocket/circuitws.js`
- `websocket/circuitws_server.py`

### Other explicit or ambiguous headers

- `build.gradle`: 4: //  License:    GPLv3; 169: include 'LICENSE'
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java`: 2: * Derived from EJML (Efficient Java Matrix Library); 3: * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved.; 5: * Licensed under the Apache License, Version 2.0 (the "License");; 6: * you may not use this file except in compliance with the License.; 7: * You may obtain a copy of the License at
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java`: 2: * Derived from EJML (Efficient Java Matrix Library); 3: * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved.; 5: * Licensed under the Apache License, Version 2.0 (the "License");; 6: * you may not use this file except in compliance with the License.; 7: * You may obtain a copy of the License at
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java`: 2: * Derived from EJML (Efficient Java Matrix Library); 3: * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved.; 5: * Licensed under the Apache License, Version 2.0 (the "License");; 6: * you may not use this file except in compliance with the License.; 7: * You may obtain a copy of the License at
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java`: 2: * Derived from EJML (Efficient Java Matrix Library); 3: * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved.; 5: * Licensed under the Apache License, Version 2.0 (the "License");; 6: * you may not use this file except in compliance with the License.; 7: * You may obtain a copy of the License at
- `war/font/webfontlicense.html`: 11: <h3>Font license info</h3>; 13: <p>Copyright (C) 2016 by Dave Gandy</p>; 15: License: SIL (<a href="http://scripts.sil.org/OFL" target="_blank">http://scripts.sil.org/OFL</a>)<br>; 18: <p>Copyright (C) 2012 by Daniel Bruce</p>; 20: License: SIL (<a href="http://scripts.sil.org/OFL" target="_blank">http://scripts.sil.org/OFL</a>)<br>
- `war/index.html`: 69: <p>Modifications Copyright © 2026 Nerding and Hoarding. Distributed under the <a href="LICENSE">GNU General Public License v3 or later</a>.</p>

### Potential exceptions and external-origin references (automated review queue)

- `build.gradle:4` — //  License:    GPLv3
- `build.gradle:169` — include 'LICENSE'
- `scripts/package-windows.ps1:45` — foreach ($notice in @("LICENSE", "COPYING.txt", "LICENSING.md", "MODIFICATIONS.md", "THIRD_PARTY_NOTICES.md", "README.md")) {
- `src/com/lushprojects/circuitjs1/client/ACRailElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ACVoltageElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ADCElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AMElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AboutBox.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AmmeterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AnalogMuxElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AnalogSwitch2Elm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AnalogSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AndGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AntennaElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AudioInputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/BatteryElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/BatteryElm.java:31` — // Vsrc's voltage is derived from the state of charge (SOC) via a configurable
- `src/com/lushprojects/circuitjs1/client/BoxElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/BusLogicInputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/BusSplitterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/BusTransceiverElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CC2Elm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CCCSElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CCVSElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CapacitorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Checkbox.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CheckboxAlignedMenuItem.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CheckboxMenuItem.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ChipElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Choice.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CirSim.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CircuitElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CircuitNode.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CircuitNodeLink.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ClockElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Color.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Counter2Elm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CounterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CrossSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CrystalElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CurrentElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CustomCompositeChipElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CustomTransformerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DACElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DCMotorElm.java:7` — // based on https://ctms.engin.umich.edu/CTMS/index.php?example=MotorPosition&section=SystemModeling
- `src/com/lushprojects/circuitjs1/client/DCVoltageElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DFlipFlopElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DPDTSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DataInputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DeMultiplexerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DecimalDisplayElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DelayBufferElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DiacElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Dialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Diode.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DiodeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/EditCompositeModelDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/EditDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/EditDialogLoadFile.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/EditInfo.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/EditOptions.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ExportAsImageDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ExportAsLocalFileDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ExportAsTextDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ExportAsUrlDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ExtVoltageElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/FFT.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/FFT.java:52` — * Based on
- `src/com/lushprojects/circuitjs1/client/FMElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Font.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/FullAdderElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/FuseElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/GateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/GraphicElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Graphics.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/GroundElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/GyratorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/HalfAdderElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ImportFromTextDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Inductor.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/InductorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/InstructionDisplayElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/InverterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/InvertingSchmittElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/JKFlipFlopElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/JfetElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/JfetElm.java:137` — // these values are taken from Hayes+Horowitz p155
- `src/com/lushprojects/circuitjs1/client/KeyNames.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LEDArrayElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LEDElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LabeledNodeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LampElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LampElm.java:169` — // based on http://www.intusoft.com/nlpdf/nl11.pdf
- `src/com/lushprojects/circuitjs1/client/LatchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LineElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LoadFile.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LogicInputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LogicOutputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/MBBSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/MemristorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Menus.java:18` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/MonostableElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/MosfetElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/MosfetModel.java:131` — // values taken from Hayes+Horowitz p155.  JFETs never show a bulk/body terminal.
- `src/com/lushprojects/circuitjs1/client/MotorProtectionSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/MouseManager.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/MultiplexerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/MyCommand.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/NJfetElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/NMosfetElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/NTransistorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/NandGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/NoiseElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/NorGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/NortonAmpElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/OpAmpElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/OpAmpSwapElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/OptocouplerElm.java:128` — // adapted from ChipElm
- `src/com/lushprojects/circuitjs1/client/OrGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/OutputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/PMosfetElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/PTransistorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/PhaseCompElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/PisoShiftElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Point.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Polygon.java:2` — //    Copyright 1995-2006 Sun Microsystems, Inc.  All Rights Reserved
- `src/com/lushprojects/circuitjs1/client/Polygon.java:15` — //    along with this program.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/PotElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ProbeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ProbeElm.java:27` — // much of this was adapted from Bill Collis's code in TestPointElm.java
- `src/com/lushprojects/circuitjs1/client/PushSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/QueryParameters.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ROMElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/RailElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Rectangle.java:2` — //    Copyright 1995-2006 Sun Microsystems, Inc.  All Rights Reserved
- `src/com/lushprojects/circuitjs1/client/Rectangle.java:15` — //    along with this program.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/RelayCoilElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/RelayContactElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/RelayElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ResistorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/RingCounterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/RoutedWireElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SCRElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SRAMElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SRAMLoadFile.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SchmittElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Scope.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ScopeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ScopeManager.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ScopePlot.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ScopePopupMenu.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ScopePropertiesDialog.java:861` — // Show/hide trigger details based on section expansion
- `src/com/lushprojects/circuitjs1/client/ScopeTrigger.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ScrollValuePopup.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Scrollbar.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SearchDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SeqGenElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SevenSegDecoderElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SevenSegElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ShortcutsDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SimulationManager.java:135` — // detect bus widths for wires based on connected elements
- `src/com/lushprojects/circuitjs1/client/SimulationManager.java:297` — // assign nodes to UI wires (which aren't part of simulation) based on neighboring non-wire elements
- `src/com/lushprojects/circuitjs1/client/SimulationManager.java:538` — // its internal node list based on final child element state
- `src/com/lushprojects/circuitjs1/client/SimulationManager.java:1701` — // Dispatching lu_factor: uses sparse or dense solver based on solverType setting
- `src/com/lushprojects/circuitjs1/client/SimulationManager.java:1796` — // Dispatching lu_solve: uses sparse or dense solver based on solverType setting
- `src/com/lushprojects/circuitjs1/client/SipoShiftElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SliderDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SparkGapElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SquareRailElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/StopTriggerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:21` — General Public License for more details.
- `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:29` — making a combined work based on this library.  Thus, the terms and
- `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:35` — executable, regardless of the license terms of these independent
- `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:38` — independent module, the terms and conditions of the license of that
- `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:39` — module.  An independent module is a module which is not derived from
- `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:40` — or based on this library.  If you modify this library, you may extend
- `src/com/lushprojects/circuitjs1/client/SweepElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Switch2Elm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TFlipFlopElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TappedTransformerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TestCreator.java:44` — // determine direction away from chip based on pin side
- `src/com/lushprojects/circuitjs1/client/TestPointElm.java:22` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TextElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ThreePhaseMotorElm.java:9` — // based on https://ctms.engin.umich.edu/CTMS/index.php?example=MotorPosition&section=SystemModeling
- `src/com/lushprojects/circuitjs1/client/ThreePhaseMotorElm.java:119` — // based on https://forum.kicad.info/t/ac-motors-simulation-1-phase-3-phase/14188/3
- `src/com/lushprojects/circuitjs1/client/TimeDelayRelayElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TimerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TransLineElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TransformerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TransistorElm.java:18` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TriStateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TriacElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TriodeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TunnelDiodeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TypeScrollPopup.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/UndoManager.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/UnijunctionElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/VCCSElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/VCOElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/VCVSElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/VarRailElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/VoltageElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/WattmeterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/WireElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/XMLDeserializer.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/XMLSerializer.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/XnorGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/XorGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ZenerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/circuitjs1.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:2` — * Derived from EJML (Efficient Java Matrix Library)
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:3` — * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved.
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:6` — * you may not use this file except in compliance with the License.
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:7` — * You may obtain a copy of the License at
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:9` — *   http://www.apache.org/licenses/LICENSE-2.0
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:12` — * distributed under the License is distributed on an "AS IS" BASIS,
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:14` — * See the License for the specific language governing permissions and
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:15` — * limitations under the License.
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java:2` — * Derived from EJML (Efficient Java Matrix Library)
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java:3` — * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved.
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java:6` — * you may not use this file except in compliance with the License.
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java:7` — * You may obtain a copy of the License at
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java:9` — *   http://www.apache.org/licenses/LICENSE-2.0
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java:12` — * distributed under the License is distributed on an "AS IS" BASIS,
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java:14` — * See the License for the specific language governing permissions and
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java:15` — * limitations under the License.
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java:2` — * Derived from EJML (Efficient Java Matrix Library)
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java:3` — * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved.
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java:6` — * you may not use this file except in compliance with the License.
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java:7` — * You may obtain a copy of the License at
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java:9` — *   http://www.apache.org/licenses/LICENSE-2.0
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java:12` — * distributed under the License is distributed on an "AS IS" BASIS,
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java:14` — * See the License for the specific language governing permissions and
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java:15` — * limitations under the License.
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:2` — * Derived from EJML (Efficient Java Matrix Library)
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:3` — * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved.
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:6` — * you may not use this file except in compliance with the License.
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:7` — * You may obtain a copy of the License at
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:9` — *   http://www.apache.org/licenses/LICENSE-2.0
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:12` — * distributed under the License is distributed on an "AS IS" BASIS,
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:14` — * See the License for the specific language governing permissions and
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:15` — * limitations under the License.
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:154` — throw new IllegalArgumentException("Unexpected number of rows in B based on shape of A. Found=" + var10002 + " Expected=" + this.AnumRows);
- `src/com/lushprojects/circuitjs1/client/util/Locale.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `war/about.html:25` — <p style="font-size:9px">This program uses free icons. For more information, please read the <a href="font/webfontlicense.html" target="_self">list of authors and licenses of these icons and webfonts</a>.</p>
- `war/about.html:28` — <p style="font-size:9px">For details of licensing see <a href="http://www.gnu.org/licenses/" target="_blank">http://www.gnu.org/licenses/</a>.</p>
- `war/about.html:33` — All rights reserved.</p>
- `war/avr8js/src.avr8js.js:92` — // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
- `war/avr8js/src.avr8js.js:129` — * @license
- `war/avr8js/src.avr8js.js:130` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:131` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:132` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:187` — * @license
- `war/avr8js/src.avr8js.js:188` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:189` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:190` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:472` — * @license
- `war/avr8js/src.avr8js.js:473` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:474` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:475` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:641` — * @license
- `war/avr8js/src.avr8js.js:642` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:643` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:644` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:717` — * @license
- `war/avr8js/src.avr8js.js:718` — * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:719` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:720` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:755` — * @license
- `war/avr8js/src.avr8js.js:756` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:757` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:758` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:920` — * @license
- `war/avr8js/src.avr8js.js:921` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:922` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:923` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:962` — // parser. The marker type is based on whether the expression is in an
- `war/avr8js/src.avr8js.js:1063` — * @license
- `war/avr8js/src.avr8js.js:1064` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:1065` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:1066` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:1615` — * @license
- `war/avr8js/src.avr8js.js:1616` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:1617` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:1618` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:1684` — * @license
- `war/avr8js/src.avr8js.js:1685` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:1686` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:1687` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:1746` — * @license
- `war/avr8js/src.avr8js.js:1747` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:1748` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:1749` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:1997` — * @license
- `war/avr8js/src.avr8js.js:1998` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:1999` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:2000` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:2094` — * @license
- `war/avr8js/src.avr8js.js:2095` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:2096` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:2097` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:2373` — // (which might cause them to render based on a common pattern of
- `war/avr8js/src.avr8js.js:2419` — * @license
- `war/avr8js/src.avr8js.js:2420` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:2421` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:2422` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:2969` — * be called when an element should update based on some state not triggered
- `war/avr8js/src.avr8js.js:3204` — * @license
- `war/avr8js/src.avr8js.js:3205` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:3206` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:3207` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:3579` — @license
- `war/avr8js/src.avr8js.js:3580` — Copyright (c) 2019 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:3581` — This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:3582` — http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
- `war/avr8js/src.avr8js.js:3748` — * @license
- `war/avr8js/src.avr8js.js:3749` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:3750` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:3751` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:3870` — } // There are three separate cases here based on Shadow DOM support.
- `war/avr8js/src.avr8js.js:6435` — * @license
- `war/avr8js/src.avr8js.js:6436` — * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:6437` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:6438` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:6538` — /** The potentiometer SVG is taken from https://freesvg.org/potentiometer and some of the
- `war/avr8js/src.avr8js.js:6539` — functions are taken from https://github.com/vitaliy-bobrov/js-rocks knob component */
- `war/avr8js/src.avr8js.js:7372` — * @license
- `war/avr8js/src.avr8js.js:7373` — * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:7374` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:7375` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:7462` — }); // Add or remove classes based on their classMap value
- `war/avr8js/src.avr8js.js:8177` — * Instruction timing is currently based on ATmega328p (see the Instruction Set Summary at the end of
- `war/doc/DataInput.html:10` — <p>The Data Input Element in CircuitJS1 allows you to simulate a voltage source where the voltage values change over time based on data from a file you provide. It's like connecting a circuit to real-world data or pre-calculated voltage sequences.</p>
- `war/doc/circuits.html:2308` — </span>The phase comparator and VCO in this applet are based on the <a
- `war/doc/welcome.html:2413` — </span>The phase comparator and VCO in this applet are based on the <a
- `war/font/fontello.css:49` — /* Font smoothing. That was taken from TWBS */
- `war/font/webfontlicense.html:11` — <h3>Font license info</h3>
- `war/font/webfontlicense.html:15` — License: SIL (<a href="http://scripts.sil.org/OFL" target="_blank">http://scripts.sil.org/OFL</a>)<br>
- `war/font/webfontlicense.html:20` — License: SIL (<a href="http://scripts.sil.org/OFL" target="_blank">http://scripts.sil.org/OFL</a>)<br>
- `war/font/webfontlicense.html:23` — <p>Copyright (c) 2012 by John Caserta. All rights reserved.</p>
- `war/font/webfontlicense.html:25` — License: SIL (<a href="http://scripts.sil.org/OFL" target="_blank">http://scripts.sil.org/OFL</a>)<br>
- `war/font/webfontlicense.html:30` — License: SIL (<a href="http://scripts.sil.org/OFL" target="_blank">http://scripts.sil.org/OFL</a>)<br>
- `war/font/webfontlicense.html:33` — <h3>Icon license info</h3>

### Excluded source candidates for separate dependency/generated-code review

- `gradlew`
- `gradlew.bat`
- `war/canvas2svg.js`
- `war/lz-string.min.js`

## circuitjs-lvlabs

Commit `c2cd5dc2574480bd3ce90bb98aa782c6956ea1d6`. Tracked files: **737**; source candidates by extension/name: **293**; excluded candidate files: **4**; identified first-party candidates: **289**; read successfully: **289**; unreadable: **0**. Other tracked files excluded: **444**. Working tree status: clean.

### Inventory by top directory and language

| Directory | Extension | Count |
|---|---|---:|
| `.` | `.gradle` | 1 |
| `lang` | `.py` | 3 |
| `lang` | `.sh` | 1 |
| `src` | `.css` | 1 |
| `src` | `.java` | 243 |
| `src` | `.xml` | 1 |
| `war` | `.css` | 2 |
| `war` | `.html` | 33 |
| `war` | `.js` | 2 |
| `war` | `.sh` | 1 |
| `war` | `.xml` | 1 |

### Header groups

| Group | Files | Eligibility |
|---|---:|---|
| Other / ambiguous license notice | 2 | UNVERIFIED: assess individual notice and origin |
| No explicit license header | 99 | UNVERIFIED: assess individual notice and origin |
| GPL 2 or later notice | 184 | CONDITIONAL: preserve notices; GPLv3 option subject to provenance |
| Apache notice | 4 | UNVERIFIED: assess individual notice and origin |

Explicit license header: **190**; without explicit license header: **99**. No blanket incompatibility is inferred from absence: the project-level notice (see Phase 1A) is evidence of intended scope, but origin and authority require later verification. The automated flag list below is a review queue, not a count of proven conflicts.

### Copyright declarations

- * Copyright (C) 2019, 2020 Uri Shaked — 1 occurrence(s), e.g. `war/avr8js/src.avr8js.js:8180`
- * Copyright (C) 2019, 2020, Uri Shaked — 2 occurrence(s), e.g. `war/avr8js/src.avr8js.js:9210`
- * Copyright (C) 2019, Uri Shaked — 3 occurrence(s), e.g. `war/avr8js/src.avr8js.js:7882`
- * Copyright (C) 2020, Uri Shaked — 1 occurrence(s), e.g. `war/avr8js/src.avr8js.js:10648`
- * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved. — 4 occurrence(s), e.g. `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:3`
- * Copyright (c) 2017 The Polymer Project Authors. All rights reserved. — 15 occurrence(s), e.g. `war/avr8js/src.avr8js.js:130`
- * Copyright (c) 2018 The Polymer Project Authors. All rights reserved. — 3 occurrence(s), e.g. `war/avr8js/src.avr8js.js:718`
- //    Copyright 1995-2006 Sun Microsystems, Inc.  All Rights Reserved — 2 occurrence(s), e.g. `src/com/lushprojects/circuitjs1/client/Polygon.java:2`
- <p>Copyright (C) 2012 by Daniel Bruce</p> — 1 occurrence(s), e.g. `war/font/webfontlicense.html:18`
- <p>Copyright (C) 2013 by Aristeides Stathopoulos</p> — 1 occurrence(s), e.g. `war/font/webfontlicense.html:28`
- <p>Copyright (C) 2016 by Dave Gandy</p> — 1 occurrence(s), e.g. `war/font/webfontlicense.html:13`
- <p>Copyright (c) 2012 by John Caserta. All rights reserved.</p> — 1 occurrence(s), e.g. `war/font/webfontlicense.html:23`
- <p>canvas2svg: Copyright (c) 2014 Gliffy Inc.</p> — 1 occurrence(s), e.g. `war/about.html:43`
- As a special exception, the copyright holders of this library give you — 1 occurrence(s), e.g. `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:33`
- COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER — 1 occurrence(s), e.g. `war/about.html:49`
- Copyright (C) 1998, 1999, 2001, 2002, 2005  Free Software Foundation, Inc. — 1 occurrence(s), e.g. `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:9`
- Copyright (C) Paul Falstad — 5 occurrence(s), e.g. `src/com/lushprojects/circuitjs1/client/CCCSElm.java:2`
- Copyright (C) Paul Falstad and Iain Sharp — 175 occurrence(s), e.g. `src/com/lushprojects/circuitjs1/client/ACRailElm.java:2`
- Copyright (c) 1985-1991 The Regents of the University of California. — 1 occurrence(s), e.g. `war/about.html:32`
- Copyright (c) 2019 The Polymer Project Authors. All rights reserved. — 1 occurrence(s), e.g. `war/avr8js/src.avr8js.js:3580`

### Files without an explicit license header

- `lang/findmissing.py`
- `lang/getstrings.py`
- `lang/makemissing.sh`
- `lang/maketemplate.py`
- `src/com/lushprojects/circuitjs1/circuitjs1.gwt.xml`
- `src/com/lushprojects/circuitjs1/client/Adjustable.java`
- `src/com/lushprojects/circuitjs1/client/AudioOutputElm.java`
- `src/com/lushprojects/circuitjs1/client/CircuitLoader.java`
- `src/com/lushprojects/circuitjs1/client/CircuitMatrix.java`
- `src/com/lushprojects/circuitjs1/client/CommandManager.java`
- `src/com/lushprojects/circuitjs1/client/ComparatorElm.java`
- `src/com/lushprojects/circuitjs1/client/CompositeElm.java`
- `src/com/lushprojects/circuitjs1/client/CustomCompositeElm.java`
- `src/com/lushprojects/circuitjs1/client/CustomCompositeModel.java`
- `src/com/lushprojects/circuitjs1/client/CustomLogicElm.java`
- `src/com/lushprojects/circuitjs1/client/CustomLogicModel.java`
- `src/com/lushprojects/circuitjs1/client/DCMotorElm.java`
- `src/com/lushprojects/circuitjs1/client/DarlingtonElm.java`
- `src/com/lushprojects/circuitjs1/client/DataRecorderElm.java`
- `src/com/lushprojects/circuitjs1/client/DiodeModel.java`
- `src/com/lushprojects/circuitjs1/client/EditDiodeModelDialog.java`
- `src/com/lushprojects/circuitjs1/client/EditRelayModelDialog.java`
- `src/com/lushprojects/circuitjs1/client/EditTransistorModelDialog.java`
- `src/com/lushprojects/circuitjs1/client/ElementFactory.java`
- `src/com/lushprojects/circuitjs1/client/Expr.java`
- `src/com/lushprojects/circuitjs1/client/FindPathInfo.java`
- `src/com/lushprojects/circuitjs1/client/ImageExporter.java`
- `src/com/lushprojects/circuitjs1/client/ImportFromDropbox.java`
- `src/com/lushprojects/circuitjs1/client/ImportFromDropboxDialog.java`
- `src/com/lushprojects/circuitjs1/client/IntPair.java`
- `src/com/lushprojects/circuitjs1/client/JSInterface.java`
- `src/com/lushprojects/circuitjs1/client/LDRElm.java`
- `src/com/lushprojects/circuitjs1/client/NDarlingtonElm.java`
- `src/com/lushprojects/circuitjs1/client/OTAElm.java`
- `src/com/lushprojects/circuitjs1/client/OhmMeterElm.java`
- `src/com/lushprojects/circuitjs1/client/OpAmpRealElm.java`
- `src/com/lushprojects/circuitjs1/client/OptocouplerElm.java`
- `src/com/lushprojects/circuitjs1/client/PDarlingtonElm.java`
- `src/com/lushprojects/circuitjs1/client/PolarCapacitorElm.java`
- `src/com/lushprojects/circuitjs1/client/RelayModel.java`
- `src/com/lushprojects/circuitjs1/client/ScopeDataIterator.java`
- `src/com/lushprojects/circuitjs1/client/ScopeFFT.java`
- `src/com/lushprojects/circuitjs1/client/ScopeOverlays.java`
- `src/com/lushprojects/circuitjs1/client/ScopePlot2d.java`
- `src/com/lushprojects/circuitjs1/client/ScopePropertiesDialog.java`
- `src/com/lushprojects/circuitjs1/client/ScopeSerializer.java`
- `src/com/lushprojects/circuitjs1/client/SimulationManager.java`
- `src/com/lushprojects/circuitjs1/client/SubcircuitBar.java`
- `src/com/lushprojects/circuitjs1/client/SubcircuitDialog.java`
- `src/com/lushprojects/circuitjs1/client/Theme.java`
- `src/com/lushprojects/circuitjs1/client/ThermistorNTCElm.java`
- `src/com/lushprojects/circuitjs1/client/ThreePhaseMotorElm.java`
- `src/com/lushprojects/circuitjs1/client/Toolbar.java`
- `src/com/lushprojects/circuitjs1/client/TransistorModel.java`
- `src/com/lushprojects/circuitjs1/client/UIManager.java`
- `src/com/lushprojects/circuitjs1/client/VaractorElm.java`
- `src/com/lushprojects/circuitjs1/client/VoltageSource.java`
- `src/com/lushprojects/circuitjs1/client/WireConverter.java`
- `src/com/lushprojects/circuitjs1/client/WireRouter.java`
- `src/com/lushprojects/circuitjs1/client/util/PerfMonitor.java`
- `src/com/lushprojects/circuitjs1/public/style.css`
- `src/com/lushprojects/circuitjs1/rebind/ElementFactoryGenerator.java`
- `war/404.html`
- `war/WEB-INF/web.xml`
- `war/avr8js/analog.html`
- `war/avr8js/index.html`
- `war/avr8js/logic.html`
- `war/avr8js/src.avr8js.css`
- `war/avr8js/src.avr8js.js`
- `war/blink-test.html`
- `war/circuitjs.html`
- `war/crystal.html`
- `war/customfunction.html`
- `war/customlogic.html`
- `war/customtransformer.html`
- `war/diodecalc.html`
- `war/doc/AudioInput.html`
- `war/doc/DataInput.html`
- `war/doc/DelayBuffer.html`
- `war/doc/circuits.html`
- `war/doc/customfunction.html`
- `war/doc/customlogic.html`
- `war/doc/customtransformer.html`
- `war/doc/index.html`
- `war/doc/js-interface.html`
- `war/doc/opampreal.html`
- `war/doc/overview.html`
- `war/doc/subcircuits.html`
- `war/doc/toc.html`
- `war/doc/welcome.html`
- `war/font/fontello.css`
- `war/iframe.html`
- `war/index.html`
- `war/jsinterface.html`
- `war/mosfet-beta.html`
- `war/opampreal.html`
- `war/service-worker.js`
- `war/subcircuits.html`
- `war/update-service-worker.sh`

### Other explicit or ambiguous headers

- `build.gradle`: 4: //  License:    GPLv3
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java`: 2: * Derived from EJML (Efficient Java Matrix Library); 3: * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved.; 5: * Licensed under the Apache License, Version 2.0 (the "License");; 6: * you may not use this file except in compliance with the License.; 7: * You may obtain a copy of the License at
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java`: 2: * Derived from EJML (Efficient Java Matrix Library); 3: * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved.; 5: * Licensed under the Apache License, Version 2.0 (the "License");; 6: * you may not use this file except in compliance with the License.; 7: * You may obtain a copy of the License at
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java`: 2: * Derived from EJML (Efficient Java Matrix Library); 3: * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved.; 5: * Licensed under the Apache License, Version 2.0 (the "License");; 6: * you may not use this file except in compliance with the License.; 7: * You may obtain a copy of the License at
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java`: 2: * Derived from EJML (Efficient Java Matrix Library); 3: * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved.; 5: * Licensed under the Apache License, Version 2.0 (the "License");; 6: * you may not use this file except in compliance with the License.; 7: * You may obtain a copy of the License at
- `war/font/webfontlicense.html`: 11: <h3>Font license info</h3>; 13: <p>Copyright (C) 2016 by Dave Gandy</p>; 15: License: SIL (<a href="http://scripts.sil.org/OFL" target="_blank">http://scripts.sil.org/OFL</a>)<br>; 18: <p>Copyright (C) 2012 by Daniel Bruce</p>; 20: License: SIL (<a href="http://scripts.sil.org/OFL" target="_blank">http://scripts.sil.org/OFL</a>)<br>

### Potential exceptions and external-origin references (automated review queue)

- `build.gradle:4` — //  License:    GPLv3
- `src/com/lushprojects/circuitjs1/client/ACRailElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ACVoltageElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ADCElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AMElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AboutBox.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AmmeterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AnalogMuxElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AnalogSwitch2Elm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AnalogSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AndGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AntennaElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/AudioInputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/BoxElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/BusLogicInputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/BusSplitterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/BusTransceiverElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CC2Elm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CCCSElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CCVSElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CapacitorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Checkbox.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CheckboxAlignedMenuItem.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CheckboxMenuItem.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ChipElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Choice.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CirSim.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CircuitElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CircuitNode.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CircuitNodeLink.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ClockElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Color.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Counter2Elm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CounterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CrossSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CrystalElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CurrentElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CustomCompositeChipElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/CustomTransformerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DACElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DCMotorElm.java:7` — // based on https://ctms.engin.umich.edu/CTMS/index.php?example=MotorPosition&section=SystemModeling
- `src/com/lushprojects/circuitjs1/client/DCVoltageElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DFlipFlopElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DPDTSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DataInputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DeMultiplexerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DecimalDisplayElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DelayBufferElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DiacElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Dialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Diode.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/DiodeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/EditCompositeModelDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/EditDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/EditDialogLoadFile.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/EditInfo.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/EditOptions.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ExportAsImageDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ExportAsLocalFileDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ExportAsTextDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ExportAsUrlDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ExtVoltageElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/FFT.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/FFT.java:52` — * Based on
- `src/com/lushprojects/circuitjs1/client/FMElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Font.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/FullAdderElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/FuseElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/GateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/GraphicElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Graphics.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/GroundElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/GyratorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/HalfAdderElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ImportFromTextDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Inductor.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/InductorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/InstructionDisplayElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/InverterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/InvertingSchmittElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/JKFlipFlopElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/JfetElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/JfetElm.java:131` — // these values are taken from Hayes+Horowitz p155
- `src/com/lushprojects/circuitjs1/client/LEDArrayElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LEDElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LabeledNodeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LampElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LampElm.java:169` — // based on http://www.intusoft.com/nlpdf/nl11.pdf
- `src/com/lushprojects/circuitjs1/client/LatchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LineElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LoadFile.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LogicInputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/LogicOutputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/MBBSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/MemristorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Menus.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/MonostableElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/MosfetElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/MotorProtectionSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/MouseManager.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/MultiplexerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/MyCommand.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/NJfetElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/NMosfetElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/NTransistorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/NandGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/NoiseElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/NorGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/NortonAmpElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/OpAmpElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/OpAmpSwapElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/OptocouplerElm.java:128` — // adapted from ChipElm
- `src/com/lushprojects/circuitjs1/client/OrGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/OutputElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/PMosfetElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/PTransistorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/PhaseCompElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/PisoShiftElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Point.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Polygon.java:2` — //    Copyright 1995-2006 Sun Microsystems, Inc.  All Rights Reserved
- `src/com/lushprojects/circuitjs1/client/Polygon.java:15` — //    along with this program.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/PotElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ProbeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ProbeElm.java:27` — // much of this was adapted from Bill Collis's code in TestPointElm.java
- `src/com/lushprojects/circuitjs1/client/PushSwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/QueryParameters.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ROMElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/RailElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Rectangle.java:2` — //    Copyright 1995-2006 Sun Microsystems, Inc.  All Rights Reserved
- `src/com/lushprojects/circuitjs1/client/Rectangle.java:15` — //    along with this program.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/RelayCoilElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/RelayContactElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/RelayElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ResistorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/RingCounterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/RoutedWireElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SCRElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SRAMElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SRAMLoadFile.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SchmittElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Scope.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ScopeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ScopeManager.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ScopePlot.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ScopePopupMenu.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ScopePropertiesDialog.java:861` — // Show/hide trigger details based on section expansion
- `src/com/lushprojects/circuitjs1/client/ScopeTrigger.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ScrollValuePopup.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Scrollbar.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SearchDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SeqGenElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SevenSegDecoderElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SevenSegElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ShortcutsDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SimulationManager.java:135` — // detect bus widths for wires based on connected elements
- `src/com/lushprojects/circuitjs1/client/SimulationManager.java:297` — // assign nodes to UI wires (which aren't part of simulation) based on neighboring non-wire elements
- `src/com/lushprojects/circuitjs1/client/SimulationManager.java:534` — // its internal node list based on final child element state
- `src/com/lushprojects/circuitjs1/client/SimulationManager.java:1691` — // Dispatching lu_factor: uses sparse or dense solver based on solverType setting
- `src/com/lushprojects/circuitjs1/client/SimulationManager.java:1786` — // Dispatching lu_solve: uses sparse or dense solver based on solverType setting
- `src/com/lushprojects/circuitjs1/client/SipoShiftElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SliderDialog.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SparkGapElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SquareRailElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/StopTriggerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:21` — General Public License for more details.
- `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:29` — making a combined work based on this library.  Thus, the terms and
- `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:35` — executable, regardless of the license terms of these independent
- `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:38` — independent module, the terms and conditions of the license of that
- `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:39` — module.  An independent module is a module which is not derived from
- `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:40` — or based on this library.  If you modify this library, you may extend
- `src/com/lushprojects/circuitjs1/client/SweepElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/Switch2Elm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/SwitchElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TFlipFlopElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TappedTransformerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TestPointElm.java:22` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TextElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ThreePhaseMotorElm.java:9` — // based on https://ctms.engin.umich.edu/CTMS/index.php?example=MotorPosition&section=SystemModeling
- `src/com/lushprojects/circuitjs1/client/ThreePhaseMotorElm.java:119` — // based on https://forum.kicad.info/t/ac-motors-simulation-1-phase-3-phase/14188/3
- `src/com/lushprojects/circuitjs1/client/TimeDelayRelayElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TimerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TransLineElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TransformerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TransistorElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TriStateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TriacElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TriodeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TunnelDiodeElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/TypeScrollPopup.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/UndoManager.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/UnijunctionElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/VCCSElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/VCOElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/VCVSElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/VarRailElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/VoltageElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/WattmeterElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/WireElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/XMLDeserializer.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/XMLSerializer.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/XnorGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/XorGateElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/ZenerElm.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/circuitjs1.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:2` — * Derived from EJML (Efficient Java Matrix Library)
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:3` — * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved.
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:6` — * you may not use this file except in compliance with the License.
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:7` — * You may obtain a copy of the License at
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:9` — *   http://www.apache.org/licenses/LICENSE-2.0
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:12` — * distributed under the License is distributed on an "AS IS" BASIS,
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:14` — * See the License for the specific language governing permissions and
- `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:15` — * limitations under the License.
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java:2` — * Derived from EJML (Efficient Java Matrix Library)
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java:3` — * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved.
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java:6` — * you may not use this file except in compliance with the License.
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java:7` — * You may obtain a copy of the License at
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java:9` — *   http://www.apache.org/licenses/LICENSE-2.0
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java:12` — * distributed under the License is distributed on an "AS IS" BASIS,
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java:14` — * See the License for the specific language governing permissions and
- `src/com/lushprojects/circuitjs1/client/matrix/DMatrixSparseCSC.java:15` — * limitations under the License.
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java:2` — * Derived from EJML (Efficient Java Matrix Library)
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java:3` — * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved.
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java:6` — * you may not use this file except in compliance with the License.
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java:7` — * You may obtain a copy of the License at
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java:9` — *   http://www.apache.org/licenses/LICENSE-2.0
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java:12` — * distributed under the License is distributed on an "AS IS" BASIS,
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java:14` — * See the License for the specific language governing permissions and
- `src/com/lushprojects/circuitjs1/client/matrix/IGrowArray.java:15` — * limitations under the License.
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:2` — * Derived from EJML (Efficient Java Matrix Library)
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:3` — * Copyright (c) 2009-2020, Peter Abeles. All Rights Reserved.
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:6` — * you may not use this file except in compliance with the License.
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:7` — * You may obtain a copy of the License at
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:9` — *   http://www.apache.org/licenses/LICENSE-2.0
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:12` — * distributed under the License is distributed on an "AS IS" BASIS,
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:14` — * See the License for the specific language governing permissions and
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:15` — * limitations under the License.
- `src/com/lushprojects/circuitjs1/client/matrix/SparseLU.java:154` — throw new IllegalArgumentException("Unexpected number of rows in B based on shape of A. Found=" + var10002 + " Expected=" + this.AnumRows);
- `src/com/lushprojects/circuitjs1/client/util/Locale.java:17` — along with CircuitJS1.  If not, see <http://www.gnu.org/licenses/>.
- `war/about.html:25` — <p style="font-size:9px">This program uses free icons. For more information, please read the <a href="font/webfontlicense.html" target="_self">list of authors and licenses of these icons and webfonts</a>.</p>
- `war/about.html:28` — <p style="font-size:9px">For details of licensing see <a href="http://www.gnu.org/licenses/" target="_blank">http://www.gnu.org/licenses/</a>.</p>
- `war/about.html:33` — All rights reserved.</p>
- `war/avr8js/src.avr8js.js:92` — // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
- `war/avr8js/src.avr8js.js:129` — * @license
- `war/avr8js/src.avr8js.js:130` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:131` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:132` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:187` — * @license
- `war/avr8js/src.avr8js.js:188` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:189` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:190` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:472` — * @license
- `war/avr8js/src.avr8js.js:473` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:474` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:475` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:641` — * @license
- `war/avr8js/src.avr8js.js:642` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:643` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:644` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:717` — * @license
- `war/avr8js/src.avr8js.js:718` — * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:719` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:720` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:755` — * @license
- `war/avr8js/src.avr8js.js:756` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:757` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:758` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:920` — * @license
- `war/avr8js/src.avr8js.js:921` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:922` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:923` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:962` — // parser. The marker type is based on whether the expression is in an
- `war/avr8js/src.avr8js.js:1063` — * @license
- `war/avr8js/src.avr8js.js:1064` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:1065` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:1066` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:1615` — * @license
- `war/avr8js/src.avr8js.js:1616` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:1617` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:1618` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:1684` — * @license
- `war/avr8js/src.avr8js.js:1685` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:1686` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:1687` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:1746` — * @license
- `war/avr8js/src.avr8js.js:1747` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:1748` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:1749` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:1997` — * @license
- `war/avr8js/src.avr8js.js:1998` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:1999` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:2000` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:2094` — * @license
- `war/avr8js/src.avr8js.js:2095` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:2096` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:2097` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:2373` — // (which might cause them to render based on a common pattern of
- `war/avr8js/src.avr8js.js:2419` — * @license
- `war/avr8js/src.avr8js.js:2420` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:2421` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:2422` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:2969` — * be called when an element should update based on some state not triggered
- `war/avr8js/src.avr8js.js:3204` — * @license
- `war/avr8js/src.avr8js.js:3205` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:3206` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:3207` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:3579` — @license
- `war/avr8js/src.avr8js.js:3580` — Copyright (c) 2019 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:3581` — This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:3582` — http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
- `war/avr8js/src.avr8js.js:3748` — * @license
- `war/avr8js/src.avr8js.js:3749` — * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:3750` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:3751` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:3870` — } // There are three separate cases here based on Shadow DOM support.
- `war/avr8js/src.avr8js.js:6435` — * @license
- `war/avr8js/src.avr8js.js:6436` — * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:6437` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:6438` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:6538` — /** The potentiometer SVG is taken from https://freesvg.org/potentiometer and some of the
- `war/avr8js/src.avr8js.js:6539` — functions are taken from https://github.com/vitaliy-bobrov/js-rocks knob component */
- `war/avr8js/src.avr8js.js:7372` — * @license
- `war/avr8js/src.avr8js.js:7373` — * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
- `war/avr8js/src.avr8js.js:7374` — * This code may only be used under the BSD style license found at
- `war/avr8js/src.avr8js.js:7375` — * http://polymer.github.io/LICENSE.txt
- `war/avr8js/src.avr8js.js:7462` — }); // Add or remove classes based on their classMap value
- `war/avr8js/src.avr8js.js:8177` — * Instruction timing is currently based on ATmega328p (see the Instruction Set Summary at the end of
- `war/doc/DataInput.html:10` — <p>The Data Input Element in CircuitJS1 allows you to simulate a voltage source where the voltage values change over time based on data from a file you provide. It's like connecting a circuit to real-world data or pre-calculated voltage sequences.</p>
- `war/doc/circuits.html:2308` — </span>The phase comparator and VCO in this applet are based on the <a
- `war/doc/welcome.html:2413` — </span>The phase comparator and VCO in this applet are based on the <a
- `war/font/fontello.css:49` — /* Font smoothing. That was taken from TWBS */
- `war/font/webfontlicense.html:11` — <h3>Font license info</h3>
- `war/font/webfontlicense.html:15` — License: SIL (<a href="http://scripts.sil.org/OFL" target="_blank">http://scripts.sil.org/OFL</a>)<br>
- `war/font/webfontlicense.html:20` — License: SIL (<a href="http://scripts.sil.org/OFL" target="_blank">http://scripts.sil.org/OFL</a>)<br>
- `war/font/webfontlicense.html:23` — <p>Copyright (c) 2012 by John Caserta. All rights reserved.</p>
- `war/font/webfontlicense.html:25` — License: SIL (<a href="http://scripts.sil.org/OFL" target="_blank">http://scripts.sil.org/OFL</a>)<br>
- `war/font/webfontlicense.html:30` — License: SIL (<a href="http://scripts.sil.org/OFL" target="_blank">http://scripts.sil.org/OFL</a>)<br>
- `war/font/webfontlicense.html:33` — <h3>Icon license info</h3>

### Excluded source candidates for separate dependency/generated-code review

- `gradlew`
- `gradlew.bat`
- `war/canvas2svg.js`
- `war/lz-string.min.js`


## Review findings and limits of this preliminary inventory

**Phase 1B status: partially complete.** The automated scan read all 839 candidates defined above (238 + 312 + 289), but the candidate set is not a validated first-party inventory. It includes third-party and generated material, documentation and configuration; it also omits possible source formats. The per-repository counts above must therefore be read as candidate counts, not first-party counts. The requested counts of identified first-party files, excluded files by origin, and conflicting or potentially incompatible files cannot yet be established. The generated queue contains many false positives, including ordinary GPL boilerplate; it has not been fully adjudicated. Do not treat the table classifications as file-by-file clearance.

The following confirmed special cases show why source-by-source review is necessary (paths are relative to each repository and evidence is at the commit recorded in that repository section):

- `src/main/java/com/lushprojects/circuitjs1/client/Polygon.java:1-7` and `Rectangle.java:1-7` in SEVA77; `src/com/lushprojects/circuitjs1/client/Polygon.java:1-7` and `Rectangle.java:1-7` in Vactrol and lvlabs: Sun Microsystems attribution, described as extracted code, with GPL-2.0-or-later notice. CONDITIONALLY eligible subject to preserving notices and verifying extraction provenance; not first-party original code.
- `src/main/java/com/lushprojects/circuitjs1/client/StringTokenizer.java:8-42` in SEVA77 and `src/com/lushprojects/circuitjs1/client/StringTokenizer.java:8-42` in Vactrol and lvlabs identify GNU Classpath, FSF copyright, GPL-2.0-or-later and a linking exception. CONDITIONALLY eligible; preserve the actual exception and notices and verify origin. The simple GPL group above does not capture the exception.
- Vactrol and lvlabs `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java:2-8`, `DMatrixSparseCSC.java:2-8`, `IGrowArray.java:2-8`, and `SparseLU.java:2-8` identify EJML, Peter Abeles, and Apache 2.0. They are externally derived and were incorrectly included as first-party candidates in the automated counts. CONDITIONALLY eligible for GPLv3 integration subject to Apache notice obligations and provenance review; they are not licensed solely under the repository GPL declaration.
- Vactrol and lvlabs `build.gradle:1-5` declares GPLv3 without an explicit later-version option. UNVERIFIED for use in an Electrow work offered under GPL-3.0-or-later: clarify whether later-version permission exists and whether copying is needed. The declaration is narrower or ambiguous relative to each repository's general statement; no claim of GPL-3.0-only is established from the shorthand alone.
- `war/avr8js/src.avr8js.js:130` and `:6538-6539` in the three repositories contains bundled external material and source references. UNVERIFIED pending separate dependency and provenance audit. It was incorrectly counted among first-party candidates.
- `war/font/webfontlicense.html` and SEVA77 `war/help/license.html` are licensing documentation, incorrectly included in candidate source counts. The latter's mention of noncommercial distribution at line 230 occurs in the GPL text's section on object-code offers; it is not a blanket noncommercial restriction on the project.

The repository declarations in `circuitjs1-seva77/README.md:90`, `circuitjs1-vactrol/LICENSING.md:5-17`, and `circuitjs-lvlabs/README.md:70-77` support a reasonable inference that ordinary unmarked project code is intended to be covered by the stated project terms, but cannot establish ownership or override specific external notices. Confirm each unmarked file's provenance before copying. No count of actual incompatible files is supported by this scan, and no complete exclusion decision can be made yet. The Phase 1A repository-level conclusion remains provisional for individual files.

Remaining work: validate source boundary and languages against all tracked paths; separate external/generated files; inspect all unmatched license and origin signals including variant wording and headers beyond 80 lines; enumerate and adjudicate every genuine exception; recompute counts and eligibility groups. The scan code in `scan_phase1b.py` documents the precise candidate rules and is provided for reproducibility; it reads repository files and writes the report.

## Refined tracked code inventory

This section supersedes the first candidate counts above. Scope is tracked programming and build scripts with extensions `.java`, `.js`, `.mjs`, `.ts`, `.tsx`, `.jsx`, `.py`, `.sh`, `.bat`, `.ps1`, `.c`, `.cpp`, `.h`, `.cs`, `.gradle`, `.iss`, `.patch`, plus `gradlew` and `Makefile`. HTML, CSS, XML, configuration, documentation, circuit data and assets are outside this code count and remain for later audit. Patches are included as code changes. A separate external-origin group is identified by file content or known bundled paths; remaining files are project source candidates, not proof of original ownership. Complete file contents were scanned, with header detection in first 80 lines. The manifest provides an exact partition of the tracked inventory and line references.

### circuitjs1-seva77

Commit `6edf7f8a405cb2c52d237182338cbb7a6e52c763`; tracked 682, code candidates 227, examined 227, unreadable 0, excluded other tracked paths 455. Exact file lists and copyright inventory: [inventory-circuitjs1-seva77.md](inventory-circuitjs1-seva77.md).

| Category | Directory | Extension | Count |
|---|---|---|---:|
| external or generated candidate | `src` | `.java` | 3 |
| external or generated candidate | `war` | `.js` | 3 |
| project code candidate | `Inno Setup` | `.iss` | 2 |
| project code candidate | `patches` | `.patch` | 17 |
| project code candidate | `scripts` | `.js` | 1 |
| project code candidate | `src` | `.java` | 199 |
| project code candidate | `templates` | `.sh` | 1 |
| project code candidate | `war` | `.js` | 1 |

| Category | Header group | Count | Eligibility |
|---|---|---:|---|
| external or generated candidate | GPL-2.0-or-later | 3 | CONDITIONAL: preserve notices; verify origin |
| external or generated candidate | no explicit license header | 2 | UNVERIFIED: establish scope or grant |
| external or generated candidate | other license reference | 1 | UNVERIFIED: establish scope or grant |
| project code candidate | GPL-2.0-or-later | 168 | CONDITIONAL: preserve notices; verify origin |
| project code candidate | no explicit license header | 53 | UNVERIFIED: establish scope or grant |

### circuitjs1-vactrol

Commit `9baa268125f70391c5c24b6e1749c308a0e25ca0`; tracked 823, code candidates 275, examined 275, unreadable 0, excluded other tracked paths 548. Exact file lists and copyright inventory: [inventory-circuitjs1-vactrol.md](inventory-circuitjs1-vactrol.md).

| Category | Directory | Extension | Count |
|---|---|---|---:|
| external or generated candidate | `gradlew` | `[none]` | 1 |
| external or generated candidate | `gradlew.bat` | `.bat` | 1 |
| external or generated candidate | `src` | `.java` | 7 |
| external or generated candidate | `war` | `.js` | 3 |
| project code candidate | `app` | `.js` | 2 |
| project code candidate | `browser-tests` | `.mjs` | 3 |
| project code candidate | `build.gradle` | `.gradle` | 1 |
| project code candidate | `dev.sh` | `.sh` | 1 |
| project code candidate | `lang` | `.py` | 3 |
| project code candidate | `lang` | `.sh` | 1 |
| project code candidate | `model-tests` | `.java` | 2 |
| project code candidate | `scripts` | `.ps1` | 1 |
| project code candidate | `src` | `.java` | 244 |
| project code candidate | `test.sh` | `.sh` | 1 |
| project code candidate | `war` | `.js` | 1 |
| project code candidate | `war` | `.sh` | 1 |
| project code candidate | `websocket` | `.js` | 1 |
| project code candidate | `websocket` | `.py` | 1 |

| Category | Header group | Count | Eligibility |
|---|---|---:|---|
| external or generated candidate | Apache-2.0 notice | 6 | CONDITIONAL: preserve notices; verify origin |
| external or generated candidate | GPL-2.0-or-later | 3 | CONDITIONAL: preserve notices; verify origin |
| external or generated candidate | no explicit license header | 2 | UNVERIFIED: establish scope or grant |
| external or generated candidate | other license reference | 1 | UNVERIFIED: establish scope or grant |
| project code candidate | GPL-2.0-or-later | 182 | CONDITIONAL: preserve notices; verify origin |
| project code candidate | GPL-3.0-or-later SPDX | 7 | CONDITIONAL: preserve notices; verify origin |
| project code candidate | GPLv3 ambiguous | 1 | UNVERIFIED: establish scope or grant |
| project code candidate | no explicit license header | 73 | UNVERIFIED: establish scope or grant |

### circuitjs-lvlabs

Commit `c2cd5dc2574480bd3ce90bb98aa782c6956ea1d6`; tracked 737, code candidates 255, examined 255, unreadable 0, excluded other tracked paths 482. Exact file lists and copyright inventory: [inventory-circuitjs-lvlabs.md](inventory-circuitjs-lvlabs.md).

| Category | Directory | Extension | Count |
|---|---|---|---:|
| external or generated candidate | `gradlew` | `[none]` | 1 |
| external or generated candidate | `gradlew.bat` | `.bat` | 1 |
| external or generated candidate | `src` | `.java` | 7 |
| external or generated candidate | `war` | `.js` | 3 |
| project code candidate | `build.gradle` | `.gradle` | 1 |
| project code candidate | `lang` | `.py` | 3 |
| project code candidate | `lang` | `.sh` | 1 |
| project code candidate | `src` | `.java` | 236 |
| project code candidate | `war` | `.js` | 1 |
| project code candidate | `war` | `.sh` | 1 |

| Category | Header group | Count | Eligibility |
|---|---|---:|---|
| external or generated candidate | Apache-2.0 notice | 6 | CONDITIONAL: preserve notices; verify origin |
| external or generated candidate | GPL-2.0-or-later | 3 | CONDITIONAL: preserve notices; verify origin |
| external or generated candidate | no explicit license header | 2 | UNVERIFIED: establish scope or grant |
| external or generated candidate | other license reference | 1 | UNVERIFIED: establish scope or grant |
| project code candidate | GPL-2.0-or-later | 180 | CONDITIONAL: preserve notices; verify origin |
| project code candidate | GPLv3 ambiguous | 1 | UNVERIFIED: establish scope or grant |
| project code candidate | no explicit license header | 62 | UNVERIFIED: establish scope or grant |


## Findings from refined code scan

The refined inventory examines **757 of 757 code candidates**: SEVA77 227, Vactrol 275, lvlabs 255, with no read failures. These figures are per snapshot and count matching paths repeatedly across forks. Project-code candidates number 221, 263 and 243 respectively; the known external/generated groups contain 6, 12 and 12 files. This is a working classification based on content and path evidence, not a definitive ownership determination. The remaining tracked files, respectively 455, 548 and 482, include data, documentation, assets and configuration, and have not been audited for embedded source or licenses. Project candidates without a detected license header number 53, 73 and 62 respectively. Project candidates with an explicit detected header number 168, 190 and 181 respectively. Exact lists are in the three linked manifests. A header is detected using the stated pattern within the first 80 lines; a negative result is not proof that a file contains no notice anywhere.

The scan identifies one ambiguous GPLv3 shorthand per Vactrol and lvlabs (`build.gradle:4`) and external material under separate terms. A defensible total for all conflicting or potentially incompatible files cannot yet be established because the complete set of source boundaries and embedded notices has not been adjudicated. No blanket incompatibility finding is justified by the reviewed material. `ProbeElm.java:24` in SEVA77 and `ProbeElm.java:27` in Vactrol and lvlabs specifically credit adaptation from Bill Collis's `TestPointElm.java`; verify the original grant and contributor history before reuse. Vactrol and lvlabs `JfetElm.java:137` and `MosfetModel.java:131` cite values from Hayes and Horowitz; SEVA77 `JfetElm.java:131` does likewise. These references warrant a provenance review and do not, by themselves, establish a restriction on the files. The detailed manifest search matches include ordinary descriptions and should not all be interpreted as restrictions.

No noncommercial restriction was identified in the reviewed first-party source search. This is a search finding, not a finding that all files or separately distributed material lack such terms. GPL headers, SPDX declarations and repository notices support conditional GPLv3 eligibility for corresponding code groups; preserve notices and verify provenance. Unmarked files remain unverified pending attribution and scope review. The Apache notices and Classpath exception require their separate notices to be preserved. Externally sourced and generated files require separate investigation. CLEAR remains unassigned because authority and provenance have not been established; INCOMPATIBLE remains unassigned because no actual conflict has been substantiated in this review.

**Status: partially complete.** Full-file automated reads are complete for the defined code candidates. First-party ownership, the entire exception list, and an exact conflict count remain unresolved; additional manual review and a check of excluded file types are required before claiming full Phase 1B completion.

## Phase 1B completion review — specific notices

This completion section supersedes earlier interim status statements and is based on the commits identified above. The classifications describe available evidence and retain Phase 1C provenance questions.

### Gradle build scripts

In Vactrol (`9baa268125f70391c5c24b6e1749c308a0e25ca0`) and lvlabs (`c2cd5dc2574480bd3ce90bb98aa782c6956ea1d6`), `build.gradle:1-9` describes this specific Gradle build script, names E:V:A, dates it 2019-03-14, gives `License: GPLv3` and references the author's CircuitJS repository. This is evidence of a separately attributed script, not a statement that changes the license of the repository. The scripts differ, so identical header language does not establish identical later changes. GPLv3 shorthand does not explicitly grant later versions and the project-level notices do not prove that E:V:A authorized one. There is no established contradiction for GPLv3 use; there is an unresolved potential obstacle to distributing a copied script with a blanket GPL-3.0-or-later grant. Classify these two files **UNVERIFIED** for that grant. Avoid copying them or establish the author's grant in Phase 1C. Electrow's license for independent application code is not blocked merely by the presence of these scripts.

### ProbeElm and TestPointElm

The corresponding `ProbeElm.java:1-17` in Vactrol and lvlabs, and `ProbeElm.java:1-17` in SEVA77 under `src/main/java/com/lushprojects/circuitjs1/client/`, declare GPL-2.0-or-later; `ProbeElm.java:27` (SEVA77 `:24`) credits adaptation from Bill Collis's `TestPointElm.java`. The checked-in `TestPointElm.java:6-26` in Vactrol and lvlabs attributes it to Bill Collis and contains the Falstad/Sharp copyright notice and GPL-2.0-or-later grant. The SEVA77 equivalent must be checked against its own header. These notices provide evidence of the applicable distribution terms for the checked-in files, but do not independently establish the original grant or its complete provenance. **CONDITIONAL**: retain notices and credit, verify the original contribution and any separate terms in Phase 1C before reuse. An earlier description that the original source was unavailable is superseded by the checked-in `TestPointElm.java`; original contribution history remains unresolved.

### circuitjs1-seva77: unmarked files and classification

The existing inventory lists every unmarked path; its completion classification assigns each candidate exactly once. Unmarked counts by classification and top-level directory: Build/configuration code / `Inno Setup`: 2, Build/configuration code / `scripts`: 1, Build/configuration code / `templates`: 1, Generated code / `war`: 2, Project code / `patches`: 14, Project code / `src`: 33, Project code / `war`: 1, Unresolved / `src`: 1.

Unmarked application files in `src` implement simulator elements, models, UI and infrastructure. Their placement within CircuitJS and repository program declarations reasonably support intended coverage, subject to contribution provenance. Language tools, service worker, tests and build scripts are related project files, but their individual ownership and inclusion in the program grant should be confirmed before copying. `LDRElm.java` identifies Bill Collis without an explicit grant; treat its origin and terms as unresolved. Where an unmarked file contains third-party material or a grant cannot be established, defer clearance to Phase 1C.

Classification counts: Project code 216, Bundled external code 4, Generated code 2, Build/configuration code 4, Unresolved 1; total 227.

### circuitjs1-vactrol: unmarked files and classification

The existing inventory lists every unmarked path; its completion classification assigns each candidate exactly once. Unmarked counts by classification and top-level directory: Build/configuration code / `dev.sh`: 1, Build/configuration code / `scripts`: 1, Build/configuration code / `test.sh`: 1, Build/configuration code / `war`: 1, Generated code / `war`: 2, Project code / `browser-tests`: 3, Project code / `lang`: 4, Project code / `model-tests`: 2, Project code / `src`: 56, Project code / `war`: 1, Project code / `websocket`: 2, Unresolved / `src`: 1.

Unmarked application files in `src` implement simulator elements, models, UI and infrastructure. Their placement within CircuitJS and repository program declarations reasonably support intended coverage, subject to contribution provenance. Language tools, service worker, tests and build scripts are related project files, but their individual ownership and inclusion in the program grant should be confirmed before copying. `LDRElm.java` identifies Bill Collis without an explicit grant; treat its origin and terms as unresolved. Where an unmarked file contains third-party material or a grant cannot be established, defer clearance to Phase 1C.

Classification counts: Project code 257, Bundled external code 8, Generated code 2, Build/configuration code 7, Unresolved 1; total 275.

### circuitjs-lvlabs: unmarked files and classification

The existing inventory lists every unmarked path; its completion classification assigns each candidate exactly once. Unmarked counts by classification and top-level directory: Build/configuration code / `war`: 1, Generated code / `war`: 2, Project code / `lang`: 4, Project code / `src`: 55, Project code / `war`: 1, Unresolved / `src`: 1.

Unmarked application files in `src` implement simulator elements, models, UI and infrastructure. Their placement within CircuitJS and repository program declarations reasonably support intended coverage, subject to contribution provenance. Language tools, service worker, tests and build scripts are related project files, but their individual ownership and inclusion in the program grant should be confirmed before copying. `LDRElm.java` identifies Bill Collis without an explicit grant; treat its origin and terms as unresolved. Where an unmarked file contains third-party material or a grant cannot be established, defer clearance to Phase 1C.

Classification counts: Project code 240, Bundled external code 8, Generated code 2, Build/configuration code 4, Unresolved 1; total 255.

### Unmarked source interpretation and attribution

Within each inventory, `src/.../client/` unmarked paths cover element and model implementations (`*Elm.java`, `*Model.java`), simulation and matrix infrastructure (`CircuitMatrix.java`, `SimulationManager.java` where present), user interface and scope functionality (`Toolbar.java`, `Scope*.java`), and utility/rebind code. Their neighboring classes and repository declarations make project coverage a reasonable inference, not an independent grant from every author. SEVA77's `patches/*.patch` are modifications to named project files; inspect each target's original terms. Its two `Inno Setup/*.iss`, `scripts/dev_n_build.js` and `templates/*.sh` are build/packaging scripts; project intent is plausible but independent authorship is not established. Vactrol's `browser-tests`, `model-tests`, `websocket`, and the shared `lang` and `war/service-worker.js` are project-related test, server, translation and runtime code; no explicit individual grant was detected. Confirm authorship and applicable project terms in Phase 1C where copying is contemplated.

`LDRElm.java` is a specific unmarked contributor-attributed exception in each snapshot: SEVA77 `src/main/java/com/lushprojects/circuitjs1/client/LDRElm.java:10`; Vactrol and lvlabs `src/com/lushprojects/circuitjs1/client/LDRElm.java:12` name Bill Collis and June 2015. Project coverage is plausible, but the original contribution and permission have not been established. **UNVERIFIED**, pending Phase 1C; this is not a finding of incompatibility. `ProbeElm` has its own explicit grant and is addressed above. SEVA77 `TestPointElm.java:4-11,21` confirms the same version-2-or-later notice and Collis attribution as the other snapshots.

### Final accounting and eligibility

Each scanned candidate appears in one completion classification in the linked per-repository inventory. Categories describe the artifact's principal role and do not settle ownership: generated bundles contain external code, and build scripts can be third party. `war/avr8js/src.avr8js.js` is identified as a bundle by its opening lines; `war/lz-string.min.js` is a minified distributed artifact. The former's component provenance and the latter's precise production method are Phase 1D questions. The two `gradlew` scripts are categorized as build files; their Apache notices are independent of the project's declarations.

| Repository | Scanned | Project | External | Generated | Build/config | Unresolved | Confirmed incompatibilities | Specific potential conflicts | GPLv3 assessment |
|---|---:|---:|---:|---:|---:|---:|---|---|---|
| SEVA77 | 227 | 216 | 4 | 2 | 4 | 1 | None identified | `LDRElm.java` grant unverified; external bundles pending | Conditional: project declaration supports GPLv3; preserve notices and resolve provenance. |
| Vactrol | 275 | 257 | 8 | 2 | 7 | 1 | None identified | `build.gradle` later-version option and `LDRElm.java` grant unverified; external bundles pending | Conditional: combined work declared GPL-3.0-or-later; verify specific grants. |
| lvlabs | 255 | 240 | 8 | 2 | 4 | 1 | None identified | `build.gradle` later-version option and `LDRElm.java` grant unverified; external bundles pending | Conditional: GPL-2.0-or-later declaration permits GPLv3; verify specific grants. |
| Total | 757 | 713 | 20 | 6 | 15 | 3 | None identified | Open questions, not a count of incompatible files | Conditional; no repository-wide clearance. |

The identified external files include `Polygon.java` and `Rectangle.java` (Sun, GPL-2.0-or-later), `StringTokenizer.java` (GNU Classpath, GPL-2.0-or-later with linking exception), `war/canvas2svg.js` (Gliffy notice) and, in Vactrol and lvlabs, four EJML-derived matrix files (Apache-2.0). Their exact paths and notices appear in the inventories and earlier review. **CONDITIONAL** for the explicitly GPL/Apache code, subject to preserving applicable notices and verifying provenance; **UNVERIFIED** for bundled JavaScript and generated artifacts until Phase 1D. GPLv3-only and GPL-2.0-only are not established by the ambiguous shorthand. No known file has been demonstrated incompatible with GPLv3 in this phase; unresolved files must not be interpreted as cleared.

### Excluded tracked files and follow-up

Excluded tracked files comprise mainly example circuit `.txt` files, HTML and CSS, images, fonts, maps, JSON, XML, documentation, binary archives and build metadata. Phase 1D should review embedded code and notices in HTML/CSS, generated maps, packaged binaries, JS dependencies, fonts/icons, circuits, documentation and build/development tools. XML, JSON and installer metadata may identify dependencies and distribution contents. Exclusion here does not establish their licensing.

**Phase 1C priorities:** (1) establish original contribution and license of each `LDRElm.java` and the Bill Collis `TestPointElm` adaptation; (2) establish E:V:A's grant and later changes to each `build.gradle`; (3) trace authorship and applicable grants of unmarked application, test, build and websocket code selected for reuse; (4) verify origin and modifications to extracted Sun, Classpath and EJML files and preserve all notices. Investigate the cited textbook model values when relevant to copied material.

**Phase 1D priorities:** (1) identify constituent licenses and notices of the AVR bundle, LZ-String, canvas2svg and Gradle wrapper; (2) audit manifests, dependencies and packaging, including source maps and build tools; (3) audit circuits, documentation, HTML/CSS, images, icons, fonts and other excluded assets; (4) determine distribution obligations for each artifact actually shipped.

**Phase 1B status: complete for the defined 757-candidate scope**, with all 757 assigned a role, known exceptions and unresolved questions recorded, and later-phase actions identified. The preceding interim “partial” statements are historical. This does not establish provenance or license clearance for every contribution, nor does it cover the excluded tracked file types.
