# Repository-level license verification

Evidence is tied to the checked-out snapshots below. This is a repository-level review only; it does not establish contributor authority, per-file exceptions, or third-party compatibility.

## `circuitjs1-seva77`

**Snapshot:** `6edf7f8a405cb2c52d237182338cbb7a6e52c763` (`master` at inspection).

- `LICENSE:1-2` is the GNU GPL, Version 2, June 1991. This is the canonical GPL-2 text; its presence alone does not grant later-version choice.
- The license text's appendix at `LICENSE:295-299` gives the sample notice: “either version 2 ... or (at your option) any later version.” That appendix is an example of how to license a program, not itself a declaration that this repository's program uses that choice.
- `README.md:90` explicitly declares the program distributable under GPL “either version 2 ... or (at your option) any later version”; lines 92-94 provide warranty and license-copy statements. This is affirmative evidence supporting **GPL-2.0-or-later** for the project as described by the README.
- Representative original Java file `src/main/java/com/lushprojects/circuitjs1/client/ACRailElm.java` carries GPL boilerplate; the repository-wide source search found the GPL form in the patch files, but line-level declarations for this representative path were not retrieved in this focused pass. Per-file scope therefore still needs confirmation.
- No root-level contradiction found between the README declaration and GPL-2 license text: the latter is the license text version, while README's program notice supplies the “or later” grant. Exact coverage of every file is not established.

**Best-supported identifier:** `GPL-2.0-or-later` for the project as declared in README. The root `LICENSE` is GPL-2 text and must not be mistaken for `GPL-2.0-only` as the complete licensing declaration.

**Electrow GPL-3.0-or-later compatibility:** At repository declaration level, compatible: “or later” permits GPLv3. This conclusion assumes the README notice is authorized for the relevant code; inherited contributor/file exceptions remain outside this phase and must be checked before copying.

## `circuitjs1-vactrol`


**Snapshot:** `9baa268125f70391c5c24b6e1749c308a0e25ca0` (`main` at inspection).

- `LICENSE:1-2` is the complete GNU GPL version 3 text. `COPYING.txt:1-2` and `COPYING.txt:298-299` contain GPL version 2 and the standard “either version 2 ... or ... any later version” program notice.
- `README.md:21` says the combined fork is distributed under GPL-3.0-or-later and attributes fork modifications to Nerding and Hoarding. `LICENSING.md:5` explicitly states GPL-3.0-or-later for the combined fork; lines 15-17 characterize the inherited CircuitJS material as GPL-2.0-or-later and preserve its notices.
- Representative inherited Java file `src/com/lushprojects/circuitjs1/client/ACRailElm.java:2-14` bears Paul Falstad and Iain Sharp copyright and the GPL notice: lines 7-9 specify GPL version 2 or (at the option of the licensee) any later version.
- Representative fork wrapper `app/main.js:2-3` declares 2026 Nerding and Hoarding copyright and `SPDX-License-Identifier: GPL-3.0-or-later`.
- No repository-level contradiction: the root GPLv3 text states terms for GPLv3-covered material, while `COPYING.txt` and inherited headers preserve the upstream GPL-2.0-or-later grant. GPLv3-only root text does not itself relicense inherited material; README/LICENSING describe the combined distribution choice. Exact authorization for every changed/inherited file is beyond this phase.

**Best-supported identifier:** **GPL-3.0-or-later for the combined fork**, based on README and `LICENSING.md`; inherited upstream files separately retain **GPL-2.0-or-later**. The root `LICENSE` is the GPLv3 text, not proof that every contained work is GPL-3.0-only.

**Electrow GPL-3.0-or-later compatibility:** The stated combined-fork terms support compatibility at repository declaration level. Inherited GPL-2.0-or-later code may be conveyed under GPLv3. New fork code is declared GPL-3.0-or-later. Confirm all files and authority before incorporation.

## `circuitjs-lvlabs`

**Snapshot:** `c2cd5dc2574480bd3ce90bb98aa782c6956ea1d6` (`master` at inspection).

- `COPYING.txt:1-2` is GPL version 2 text. Its appendix at `COPYING.txt:295-299` includes the sample “either version 2 ... or (at your option) any later version” notice; as in other GPL texts, the sample is not by itself a grant for this program.
- `README.md:72` explicitly states GPL version 2 or any later version, attributed to original source headers. `war/about.html:26` repeats the GPL “either version 2 ... or ... any later version” program notice.
- Representative first-party inherited Java source `src/com/lushprojects/circuitjs1/client/ACRailElm.java:2-14` carries Falstad/Sharp copyright and GPL version 2-or-later language at lines 7-9.
- No root/declaration contradiction identified. README and representative source header both establish later-version permission; `COPYING.txt` supplies version 2 license text.

**Best-supported identifier:** **GPL-2.0-or-later** for the CircuitJS program as declared by README, about page, and source header. `COPYING.txt` alone would be insufficient to establish “or later.”

**Electrow GPL-3.0-or-later compatibility:** Compatible at repository declaration level because the program's notices permit any later GPL version, including GPLv3. Specific exceptions and non-core materials have not been reviewed in this phase.

## Overall repository-level conclusion

The evidence supports GPL-2.0-or-later for SEVA77 and lvlabs, and GPL-3.0-or-later for the Vactrol combined fork (with inherited files retaining GPL-2.0-or-later). All three are therefore compatible at the repository-declaration level with a GPL-3.0-or-later Electrow distribution. This is not file-by-file clearance: headers, individual contributions, and authority for the Vactrol combined-fork licensing statement remain to be verified in later phases.
