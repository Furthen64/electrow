# Electrow: provisional licensing conclusion

## Decision

**GPL-3.0-or-later is a reasonable provisional license for Electrow.** The three current repository declarations support GPLv3 use of their respective CircuitJS programs, subject to the rights and terms attached to particular material. The existing audit identified **no confirmed GPLv3 incompatibility** in the reviewed code. This is not a clearance of every file, contributor, dependency, or asset, and is not a finding that the entire contents of all three repositories can be combined without further review.

Technical analysis can proceed using these repositories as references. Before copying or porting a particular implementation, evaluate that material and its dependencies against the gate below. The distinction matters because translation or close adaptation can be a modification of copyrightable code; implementing functionality independently requires a separate assessment of what was actually copied. Keep unresolved material out of an import until its terms are established or use an independently developed alternative.

## Evidence and scope

This conclusion consolidates [REPOSITORY_LICENSES.md](REPOSITORY_LICENSES.md), [FILE_LICENSE_AUDIT.md](FILE_LICENSE_AUDIT.md), and their linked inventories. It concerns the following checked-out HEADs, verified against `git rev-parse HEAD`:

| Repository | HEAD | Project declaration and interpretation |
|---|---|---|
| `circuitjs1-seva77` | `6edf7f8a405cb2c52d237182338cbb7a6e52c763` | `README.md:90` declares GPL version 2 or later for the program; `LICENSE:1-2` supplies GPLv2 text. The declaration supports `GPL-2.0-or-later`; the license text alone would not establish the later-version option. |
| `circuitjs1-vactrol` | `9baa268125f70391c5c24b6e1749c308a0e25ca0` | `README.md:21` and `LICENSING.md:5,15-17` declare the combined fork GPL-3.0-or-later and describe inherited CircuitJS grants as GPL-2.0-or-later. Representative inherited `src/com/lushprojects/circuitjs1/client/ACRailElm.java:2-9` retains a GPL-2.0-or-later notice; `app/main.js:2-3` declares GPL-3.0-or-later for wrapper modifications. |
| `circuitjs-lvlabs` | `c2cd5dc2574480bd3ce90bb98aa782c6956ea1d6` | `README.md:70-77`, `war/about.html:26` and `src/com/lushprojects/circuitjs1/client/ACRailElm.java:2-9` support GPL-2.0-or-later for the CircuitJS program; `COPYING.txt:1-2` supplies GPLv2 text. |

GPL-2.0-or-later permits use under GPLv3; GPL-3.0-or-later likewise permits GPLv3 use. Electrow's proposed declaration can cover Electrow's own work and an appropriately licensed combination, while preserving original notices and the grants applicable to inherited material. It does not give Electrow authority to change another holder's grant. Specific files may have other licenses or narrower grants; their terms control their use. If a selected component permits GPLv3 only, its presence may prevent an accurate unconditional “or later” grant for the combined work, depending on how it is incorporated and licensed. This issue has not been established for any particular component here.

Phase 1B read 757 defined tracked code candidates, not all tracked material. The completion classification and its limits are in [FILE_LICENSE_AUDIT.md](FILE_LICENSE_AUDIT.md); HTML, assets, example circuits, dependencies, and other excluded material are not cleared by that scan. The prior audit's “no confirmed incompatibility” is a finding about the evidence reviewed, not proof that none exists. No exhaustive history investigation was performed for this conclusion.

## Selection-specific questions

Paths are relative to each named repository and refer to the HEAD in the table above. These are targeted follow-ups only if the material is selected; their presence does not block technical analysis or the provisional project license.

| Material and evidence | Current assessment | Action if selected |
|---|---|---|
| All three: `LDRElm.java` under the Java client directory. SEVA77 `src/main/java/com/lushprojects/circuitjs1/client/LDRElm.java:10`; Vactrol and lvlabs `src/com/lushprojects/circuitjs1/client/LDRElm.java:12` attribute Bill Collis without an individual license notice. | **Unverified** individual grant; the repository declaration is evidence of intended project coverage, not proof of every contributor's authority. | Check contribution origin and applicable grant; preserve attribution. Do not infer incompatibility solely from a missing header. |
| All three: client `ProbeElm.java:24` in SEVA77, `:27` in Vactrol and lvlabs; client `TestPointElm.java:4-11,21` in SEVA77 and `:6-26` in the other two. | **Conditional**: Probe credits adaptation from Bill Collis's TestPoint code; both checked-in files have GPL-2.0-or-later notices. The original contribution's full provenance remains unverified. | Preserve notices and credit; verify the original contribution and any separate terms if the adapted material is selected. |
| Vactrol and lvlabs `build.gradle:1-9`. | **Unverified** later-version grant: an independently attributed script states “GPLv3,” with no explicit “or later.” This is a script-specific notice, not evidence of a repository-wide license change. GPLv3 use and GPL-3.0-or-later licensing of a combined work are distinct questions. | Avoid copying unless needed, or establish its grant and the terms of modifications; assess distribution context. |
| All three: client `Polygon.java:1-7`, `Rectangle.java:1-7`, and `StringTokenizer.java:8-42` (under `src/main/java/com/lushprojects/circuitjs1/client/` for SEVA77 and `src/com/lushprojects/circuitjs1/client/` for the others). | **Conditional**: the first two carry Sun attribution and GPL-2.0-or-later notices; StringTokenizer identifies GNU Classpath and a GPL linking exception. | Verify origin and preserve applicable copyright, license and exception notices. |
| Vactrol and lvlabs: `src/com/lushprojects/circuitjs1/client/matrix/DGrowArray.java`, `DMatrixSparseCSC.java`, `IGrowArray.java`, `SparseLU.java`, each `:2-8`. | **Conditional**: EJML-derived, Apache-2.0 notices identify Peter Abeles. Apache-2.0 material can be used with GPLv3 subject to its conditions; it is not transformed into solely original Electrow material. | Check provenance, modifications, license and any applicable NOTICE obligations; retain required notices. |
| All three: `war/avr8js/src.avr8js.js`, `war/lz-string.min.js`, `war/canvas2svg.js`; Vactrol and lvlabs `gradlew` and `gradlew.bat`. | **Unverified for the intended distribution**: bundled/generated or independently licensed material, potentially containing multiple components. | Identify actual components, licenses and distribution notices before incorporating or shipping them. The Gradle wrappers carry Apache notices; confirm the complete packaged build chain separately. |
| Unmarked project candidates listed in the `no explicit license header` sections of the three inventories. | **Conditional or unverified by selection**: repository declarations reasonably support intended coverage of ordinary project files, but location alone does not prove ownership or override external terms. | Review the selected file, origin indicators and any relevant changes. Use the inventory as a starting point, not a substitute for clearance. |
| SEVA77 client `JfetElm.java:131`; Vactrol and lvlabs client `JfetElm.java:137`, `MosfetModel.java:131`. | Cited textbook values raise a provenance question; the citations themselves do not establish a license conflict. | Review the material and source if those model values or surrounding expression are selected. |

The client directory in the table means `src/main/java/com/lushprojects/circuitjs1/client/` for SEVA77 and `src/com/lushprojects/circuitjs1/client/` for Vactrol and lvlabs. File-level notices and the three inventory files provide additional paths and copyright holders.

## Practical import gate

1. Record the donor repository, exact commit, selected paths and intended use, including copied portions, translations, adaptations, assets and dependencies.
2. Read the selected files and nearby notices; identify copyright holders, license version and any exceptions or third-party origin. Use the existing inventories to find unmarked and flagged material.
3. Resolve a specific missing grant or conflicting notice before import. Where the evidence supports the intended use, retain applicable copyright, license, attribution and exception notices, and document modifications and their dates as required by the applicable terms.
4. Before distributing source or binaries, review the whole distribution and its dependencies, provide required licenses and notices, and meet applicable GPL corresponding-source obligations. Audit bundled fonts, icons, circuits, documentation, runtimes, and other assets separately.

Unresolved questions remain selection-specific. This conclusion permits planning and technical comparison to continue; it does not authorize treating unverified material as cleared, or guarantee that a later selection will fit GPL-3.0-or-later.
